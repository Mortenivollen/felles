import asyncio
import os

from agent_framework.azure import AzureAIAgentClient
from azure.identity import AzureCliCredential
from dotenv import load_dotenv


load_dotenv()


def get_task() -> str:
    """Beginner task: write a short customer-facing update."""
    return (
        "Write a short customer update about a fixed CSV export bug. "
        "Tone should be friendly, clear, and professional."
    )


async def main() -> None:
    task = get_task()

    print("\nTask:")
    print(task)

    # Authenticate with Azure CLI (run az login first).
    credential = AzureCliCredential()

    async with AzureAIAgentClient(credential=credential) as client:
        # Agent 1: creates or revises a draft message.
        drafter = client.as_agent(
            name="loop-drafter",
            instructions=(
                "You draft short customer communications. "
                "Return only the message text, 3-5 sentences."
            ),
        )

        # Agent 2: reviews quality and gives structured feedback.
        reviewer = client.as_agent(
            name="loop-reviewer",
            instructions=(
                "Review the draft and return exactly two lines:\n"
                "1) STATUS: PASS or IMPROVE\n"
                "2) FEEDBACK: one short sentence with the most important fix."
            ),
        )

        # Iterative orchestration pattern:
        # repeat draft -> review -> revise for a few rounds.
        max_rounds = 3
        review_result = "STATUS: IMPROVE\nFEEDBACK: Start with a clear customer-facing outcome."
        current_draft = ""

        for round_number in range(1, max_rounds + 1):
            print(f"\n--- Round {round_number} ---")

            # First round drafts from task only, later rounds include reviewer feedback.
            if round_number == 1:
                draft_prompt = f"Task: {task}"
            else:
                draft_prompt = (
                    f"Task: {task}\n"
                    f"Previous draft:\n{current_draft}\n"
                    f"Reviewer notes:\n{review_result}\n"
                    "Revise the draft using the feedback."
                )

            current_draft = await drafter.run([draft_prompt])
            print("Draft:")
            print(current_draft)

            review_prompt = (
                f"Task: {task}\n"
                f"Draft to review:\n{current_draft}\n"
                "Evaluate if this is good enough for customers."
            )
            review_result = await reviewer.run([review_prompt])
            print("Review:")
            print(review_result)

            # Stop early when the reviewer approves the draft.
            if "STATUS: PASS" in review_result.upper():
                print("\nReviewer approved the draft. Stopping early.")
                break

    print("\nFinal approved (or last) draft:")
    print("-" * 60)
    print(current_draft)


if __name__ == "__main__":
    if not os.getenv("PROJECT_ENDPOINT"):
        print("PROJECT_ENDPOINT is missing. Add it to .env before running this demo.")
    else:
        asyncio.run(main())
