import asyncio
import os

from agent_framework.azure import AzureAIAgentClient
from azure.identity import AzureCliCredential
from dotenv import load_dotenv


load_dotenv()


def get_product_feedback() -> str:
    """Simple text input used by all agents in this demo."""
    return (
        "The app loads quickly and I like the new dashboard. "
        "But export to CSV fails for large files, and I had to retry several times. "
        "Please improve reliability before the next release."
    )


async def main() -> None:
    # Shared input for all specialist agents.
    feedback = get_product_feedback()

    print("\\nInput feedback:")
    print(feedback)

    # Authenticate with Azure CLI token from `az login`.
    credential = AzureCliCredential()

    async with AzureAIAgentClient(credential=credential) as client:
        # Agent A: creates a one-line summary.
        summarizer = client.as_agent(
            name="parallel-summarizer",
            instructions="Summarize the feedback in one short sentence.",
        )

        # Agent B: extracts risk/impact points.
        risk_agent = client.as_agent(
            name="parallel-risk-analyst",
            instructions=(
                "List exactly 2 risks from this feedback as short bullet points."
            ),
        )

        # Agent C: proposes one practical action.
        action_agent = client.as_agent(
            name="parallel-action-agent",
            instructions=(
                "Provide one clear next action for the product team in one sentence."
            ),
        )

        # Parallel orchestration (fan-out):
        # run three specialists at the same time on the same input.
        summary_task = summarizer.run([f"Feedback: {feedback}"])
        risk_task = risk_agent.run([f"Feedback: {feedback}"])
        action_task = action_agent.run([f"Feedback: {feedback}"])

        summary, risks, action = await asyncio.gather(
            summary_task,
            risk_task,
            action_task,
        )

        # Fan-in step: combine all parallel outputs into one beginner-friendly report.
        print("\\nParallel orchestration result:")
        print("-" * 60)
        print("Summary:")
        print(summary)
        print("\\nRisks:")
        print(risks)
        print("\\nNext action:")
        print(action)


if __name__ == "__main__":
    # Small guardrail so beginners see env setup quickly.
    if not os.getenv("PROJECT_ENDPOINT"):
        print("PROJECT_ENDPOINT is missing. Add it to .env before running this demo.")
    else:
        asyncio.run(main())
