import asyncio
import os

from agent_framework.azure import AzureAIAgentClient
from azure.identity import AzureCliCredential
from dotenv import load_dotenv


load_dotenv()


def get_user_request() -> str:
    """Change this sample line to test different routes."""
    return "I cannot sign in to my account after resetting my password."


def route_request(request_text: str) -> str:
    """
    Very simple beginner router.
    In real systems, routing can be another AI agent or a rules engine.
    """
    lowered = request_text.lower()
    if "sign in" in lowered or "password" in lowered or "login" in lowered:
        return "auth"
    if "invoice" in lowered or "billing" in lowered or "payment" in lowered:
        return "billing"
    return "general"


async def main() -> None:
    request_text = get_user_request()
    selected_route = route_request(request_text)

    print("\\nUser request:")
    print(request_text)
    print(f"\\nChosen route: {selected_route}")

    credential = AzureCliCredential()

    async with AzureAIAgentClient(credential=credential) as client:
        # Three specialists are available, but only one is executed per request.
        auth_agent = client.as_agent(
            name="auth-support-agent",
            instructions=(
                "You handle sign-in and password issues. "
                "Write a short, clear troubleshooting response for the user."
            ),
        )

        billing_agent = client.as_agent(
            name="billing-support-agent",
            instructions=(
                "You handle billing and invoices. "
                "Write a short, clear troubleshooting response for the user."
            ),
        )

        general_agent = client.as_agent(
            name="general-support-agent",
            instructions=(
                "You handle general product questions. "
                "Write a short, friendly response for the user."
            ),
        )

        # Router orchestration: send to one specialist based on intent.
        if selected_route == "auth":
            result = await auth_agent.run([request_text])
        elif selected_route == "billing":
            result = await billing_agent.run([request_text])
        else:
            result = await general_agent.run([request_text])

        print("\\nRouter orchestration result:")
        print("-" * 60)
        print(result)


if __name__ == "__main__":
    if not os.getenv("PROJECT_ENDPOINT"):
        print("PROJECT_ENDPOINT is missing. Add it to .env before running this demo.")
    else:
        asyncio.run(main())
