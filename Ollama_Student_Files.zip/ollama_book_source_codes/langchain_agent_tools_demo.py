from datetime import datetime

from langchain_core.messages import HumanMessage, SystemMessage, ToolMessage
from langchain_core.tools import tool
from langchain_ollama import ChatOllama


@tool
def get_current_time(_: str = "") -> str:
    """Return current local time."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


@tool
def calculate(expression: str) -> str:
    """Evaluate a simple math expression like 12 * (3 + 4)."""
    allowed = set("0123456789+-*/(). %")
    if not set(expression) <= allowed:
        return "Error: unsupported characters in expression."

    try:
        result = eval(expression, {"__builtins__": {}}, {})
        return str(result)
    except Exception as exc:
        return f"Error: {exc}"


TOOLS = [get_current_time, calculate]
TOOLS_BY_NAME = {tool_fn.name: tool_fn for tool_fn in TOOLS}

llm = ChatOllama(model="llama3.2:3b", temperature=0)
llm_with_tools = llm.bind_tools(TOOLS)


SYSTEM_TEXT = (
    "You are a practical assistant. "
    "Use tools when needed for time and math. "
    "If no tool is needed, answer directly and briefly."
)


def run_agent_turn(messages: list, max_steps: int = 4) -> str:
    """Run one user turn with tool-calling loop until final answer."""
    for _ in range(max_steps):
        ai_message = llm_with_tools.invoke(messages)
        messages.append(ai_message)

        tool_calls = getattr(ai_message, "tool_calls", None) or []
        if not tool_calls:
            return ai_message.content

        for call in tool_calls:
            name = call.get("name")
            args = call.get("args", {})
            tool_call_id = call.get("id")

            tool_fn = TOOLS_BY_NAME.get(name)
            if tool_fn is None:
                tool_result = f"Unknown tool requested: {name}"
            else:
                try:
                    tool_result = tool_fn.invoke(args)
                except Exception as exc:
                    tool_result = f"Tool error from {name}: {exc}"

            messages.append(ToolMessage(content=str(tool_result), tool_call_id=tool_call_id))

    return "Stopped: max steps reached before final response."


def run_example_questions() -> None:
    questions = [
        "What time is it right now?",
        "What is (1250 * 19) / 100? Explain in one short sentence.",
        "What is the capital of Norway?",
    ]

    for question in questions:
        messages = [SystemMessage(content=SYSTEM_TEXT), HumanMessage(content=question)]
        answer = run_agent_turn(messages)
        print(f"\nUser: {question}")
        print("Assistant:", answer)


def run_interactive_chat() -> None:
    print("\nInteractive mode started. Type 'exit' to stop.")

    messages = [SystemMessage(content=SYSTEM_TEXT)]

    while True:
        user_text = input("You: ").strip()
        if user_text.lower() in {"exit", "quit"}:
            print("Goodbye.")
            break

        messages.append(HumanMessage(content=user_text))
        answer = run_agent_turn(messages)
        print("Assistant:", answer)

        # Keep history bounded for beginner-friendly token control
        if len(messages) > 25:
            messages = [messages[0]] + messages[-24:]


if __name__ == "__main__":
    run_example_questions()
    run_interactive_chat()
