"""Generate DOCX files for course-level markdown docs."""

import re
from pathlib import Path

from docx import Document


ROOT = Path(__file__).resolve().parent
DOCS = ROOT / "course_docs"
TARGETS = [
    "workspace_oversikt.md",
    "undervisningsplan_detaljert.md",
    "undervisningsplan_2_dager_komprimert.md",
    "instruktornotater_timeblokker.md",
    "deltakerhandout.md",
    "kursleder_cheat_sheet.md",
]


def markdown_to_docx(md_path: Path, docx_path: Path) -> None:
    doc = Document()

    for raw_line in md_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.rstrip()

        if not line:
            doc.add_paragraph("")
            continue

        if line.startswith("# "):
            doc.add_heading(line[2:].strip(), level=1)
            continue
        if line.startswith("## "):
            doc.add_heading(line[3:].strip(), level=2)
            continue
        if line.startswith("### "):
            doc.add_heading(line[4:].strip(), level=3)
            continue
        if line.startswith("- "):
            doc.add_paragraph(line[2:].strip(), style="List Bullet")
            continue
        if re.match(r"^\d+\.\s+", line):
            text = re.sub(r"^\d+\.\s+", "", line)
            doc.add_paragraph(text.strip(), style="List Number")
            continue

        doc.add_paragraph(line)

    doc.save(docx_path)


def main() -> int:
    for name in TARGETS:
        md_path = DOCS / name
        docx_path = DOCS / name.replace(".md", ".docx")

        if not md_path.exists():
            print(f"Skipping missing file: {md_path}")
            continue

        markdown_to_docx(md_path, docx_path)
        print(f"Generated: {docx_path}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
