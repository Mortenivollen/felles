"""Simple launcher for beginner exercises.

Usage:
    python start_exercises.py
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent

EXERCISES = {
    "1": {
        "name": "Exercise 1 - Ollama SDK prompt",
        "doc": ROOT / "exercises" / "exercise1.md",
        "start": None,
        "solution": ROOT / "solutions" / "ex1_solution.py",
    },
    "2": {
        "name": "Exercise 2 - LangChain JSON pipeline",
        "doc": ROOT / "exercises" / "exercise2.md",
        "start": None,
        "solution": ROOT / "solutions" / "ex2_solution.py",
    },
    "3": {
        "name": "Exercise 3 - Minimal RAG",
        "doc": ROOT / "exercises" / "exercise3.md",
        "start": None,
        "solution": ROOT / "solutions" / "ex3_solution.py",
    },
    "4": {
        "name": "Exercise 4 - Persona + categorizer",
        "doc": ROOT / "exercises" / "exercise4.md",
        "start": ROOT / "startscripts" / "ex4_start.py",
        "solution": ROOT / "solutions" / "ex4_solution.py",
    },
    "5": {
        "name": "Exercise 5 - LangChain tools agent",
        "doc": ROOT / "exercises" / "exercise5.md",
        "start": ROOT / "startscripts" / "ex5_start.py",
        "solution": ROOT / "solutions" / "ex5_solution.py",
    },
    "6": {
        "name": "Exercise 6 - LangGraph tool loop",
        "doc": ROOT / "exercises" / "exercise6.md",
        "start": ROOT / "startscripts" / "ex6_start.py",
        "solution": ROOT / "solutions" / "ex6_solution.py",
    },
    "7": {
        "name": "Exercise 7 - Multi-agent supervisor",
        "doc": ROOT / "exercises" / "exercise7.md",
        "start": ROOT / "startscripts" / "ex7_start.py",
        "solution": ROOT / "solutions" / "ex7_solution.py",
    },
    "8": {
        "name": "Exercise 8 - MCP tools agent",
        "doc": ROOT / "exercises" / "exercise8.md",
        "start": ROOT / "startscripts" / "ex8_start.py",
        "solution": ROOT / "solutions" / "ex8_solution.py",
    },
}


def _run_script(path: Path) -> int:
    print(f"\nRunning: {path}")
    return subprocess.call([sys.executable, str(path)], cwd=str(ROOT))


def _show_menu() -> None:
    print("\nBeginner Exercises Launcher")
    print("=" * 30)
    for key, item in EXERCISES.items():
        print(f"{key}. {item['name']}")
    print("Q. Quit")


def _show_exercise(item: dict) -> None:
    print("\nSelected:", item["name"])
    print("Doc:", item["doc"].relative_to(ROOT))
    if item["start"]:
        print("Starter:", item["start"].relative_to(ROOT))
    else:
        print("Starter: not provided (use doc tasks)")
    print("Solution:", item["solution"].relative_to(ROOT))


def main() -> int:
    while True:
        _show_menu()
        choice = input("\nChoose exercise number (or Q): ").strip().lower()
        if choice in {"q", "quit", "exit"}:
            return 0

        item = EXERCISES.get(choice)
        if not item:
            print("Invalid choice.")
            continue

        _show_exercise(item)
        action = input("Run [S]tarter, [O]solution, or [B]ack? ").strip().lower()

        if action == "s":
            if item["start"] is None:
                print("No starter for this exercise. Follow the markdown tutorial.")
            else:
                code = _run_script(item["start"])
                print(f"Exit code: {code}")
        elif action == "o":
            code = _run_script(item["solution"])
            print(f"Exit code: {code}")
        else:
            continue


if __name__ == "__main__":
    raise SystemExit(main())
