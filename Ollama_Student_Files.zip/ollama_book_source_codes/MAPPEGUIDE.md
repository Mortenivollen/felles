# Mappeguide

Her finner du alt, kort forklart.

1. [README.md](README.md) - start her.
2. [course_docs/](course_docs/) - kursplan, oversikter og guider.
3. [exercises/](exercises/) - alle oppgaver i md/docx.
4. [startscripts/](startscripts/) - startkode for oppgaver.
5. [solutions/](solutions/) - løsningsforslag.
6. [logs/](logs/) - loggfiler og genererte resultater.
7. [itil_docs/](itil_docs/) - lokale ITIL-tekster til RAG.
8. [rag_store/](rag_store/) - lokal vektordatabase (Chroma).
9. [start_exercises.py](start_exercises.py) - meny for å kjøre oppgaver.
10. [generate_exercise_docx.py](generate_exercise_docx.py) og [generate_course_docs_docx.py](generate_course_docs_docx.py) - genererer DOCX-filer.
