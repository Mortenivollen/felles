"""
rag_simple2.py — Minimal RAG using:
- LangChain for chunking (RecursiveCharacterTextSplitter)
- LangChain for embeddings (OllamaEmbeddings)
- Ollama SDK for final answer generation
- ChromaDB as the in-memory vector store

Setup (Windows):
- Install:
    pip install ollama chromadb langchain-community langchain-ollama langchain-text-splitters
- Start Ollama:
    ollama serve
- Pull models (once):
    ollama pull llama3.2
    ollama pull mxbai-embed-large
- Place constitution.txt next to this script
- Run:
    python rag_simple2.py
"""

import os
import ollama  # Use Ollama SDK for final text generation
import chromadb  # Simple in-memory vector database

# LangChain: embeddings and text splitter
from langchain_ollama import OllamaEmbeddings             # wrapper to call Ollama embedding models
from langchain_text_splitters import RecursiveCharacterTextSplitter  # robust text chunker

# Choose models and document path
LLM_MODEL = "llama3.2"           # generation model for the final answer
EMBED_MODEL = "mxbai-embed-large"  # embedding model to vectorize text
DOC_PATH = "constitution.txt"    # the document we index for RAG


def main():
    # 1) Load the source document from disk
    if not os.path.exists(DOC_PATH):
        print(f"Missing file: {DOC_PATH}")
        return
    with open(DOC_PATH, "r", encoding="utf-8") as f:
        full_text = f.read()

    # 2) Use LangChain's text splitter to make small, overlapping chunks
    #    - Small chunks improve retrieval quality
    #    - Overlap keeps continuity between chunks
    splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
    chunks = splitter.split_text(full_text)

    # 3) Create an embeddings object (LangChain -> Ollama embeddings model)
    #    - This will call your local Ollama server to compute vectors
    embedder = OllamaEmbeddings(model=EMBED_MODEL)

    # 4) Build a ChromaDB collection and add chunk vectors
    #    - chromadb.Client() creates an in-memory store (simple for demos)
    client = chromadb.Client()
    collection = client.get_or_create_collection("constitution")

    # Compute embeddings for all chunks (list of vectors)
    doc_vectors = embedder.embed_documents(chunks)

    # Add documents and embeddings with simple IDs
    ids = [f"chunk-{i}" for i in range(len(chunks))]
    collection.add(ids=ids, documents=chunks, embeddings=doc_vectors)

    # 5) Ask the user a question about the document
    question = input("\nAsk a question about the Constitution: ").strip()
    if not question:
        print("No question entered.")
        return

    # 6) Embed the user's question and query the vector store for top matches
    q_vec = embedder.embed_query(question)
    results = collection.query(query_embeddings=[q_vec], n_results=3)
    top_chunks = results["documents"][0]  # top N chunks for this single query

    # 7) Build a prompt with retrieved context + the user's question
    #    - This is the "RAG" part: we ground the LLM with relevant text
    context = "\n\n".join(top_chunks)
    prompt = (
        "Use ONLY the context below to answer the question.\n\n"
        f"Context:\n{context}\n\n"
        f"Question: {question}\n\n"
        "Answer clearly:"
    )

    # 8) Generate the final answer with the LLM via Ollama SDK
    answer = ollama.generate(model=LLM_MODEL, prompt=prompt)["response"].strip()

    # 9) Show the answer
    print("\nAnswer:\n")
    print(answer)


if __name__ == "__main__":
    main()