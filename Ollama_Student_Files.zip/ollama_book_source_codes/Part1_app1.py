# Simple example: stream generated tokens from a local Ollama server

import requests
import json

# Ollama REST endpoint for text generation (default host/port)
url = "http://localhost:11434/api/generate"

# Generation payload:
# - model: name of a model already pulled by Ollama (e.g., `ollama pull llama3.2`)
# - prompt: the text to generate a response for
data = {
    "model": "llama3.2",  # Ensure the model is available locally in Ollama
    "prompt": "Tell me a fun fact"
}

# Send POST request with streaming enabled so tokens arrive incrementally
response = requests.post(
    url,
    json=data,
    stream=True  # Stream server-sent chunks instead of waiting for the full response
)

# Check the HTTP status
if response.status_code == 200:
    print("Generated Text:", end=" ", flush=True)
    # Iterate line-by-line over the streaming response
    for line in response.iter_lines():
        if line:  # Skip keep-alive newlines
            # Convert the raw bytes line into text and parse JSON
            decoded_line = line.decode("utf-8")
            result = json.loads(decoded_line)

            # Each JSON object can contain a partial "response" token/string
            generated_text = result.get("response", "")

            # Print without newline to build the output incrementally
            print(generated_text, end="", flush=True)
else:
    # Print HTTP error code and any server-provided message
    print("Error:", response.status_code, response.text)


