# multi_agent_demo.py
#
# Beginner-friendly MULTI-AGENT demo using Ollama + LangChain + LangGraph
#
# ─────────────────────────────────────────────────────────────────────────
#  WHAT IS A MULTI-AGENT SYSTEM?
#
#  Instead of one big agent that does everything, you split the work across
#  several *specialist* agents.  A Supervisor coordinates them:
#
#  The flow is linear and deterministic — no loops:
#
#         ┌──────────┐
#    User │          │
#   ────► │Supervisor│ decides which specialist to call
#         └────┬─────┘
#              │  routes to ONE of:
#      ┌───────┴──────┐
#      ▼              ▼
#  ┌──────┐       ┌────────┐
#  │Math  │       │ Fact   │
#  │Agent │       │ Agent  │
#  └──┬───┘       └───┬────┘
#     └──────┬─────────┘
#            ▼
#      ┌──────────┐
#      │  Writer  │  polishes the answer
#      │  Agent   │
#      └────┬─────┘
#           ▼
#          END
#
#  • Math Agent   – handles arithmetic calculations
#  • Fact Agent   – answers general knowledge / factual questions
#  • Writer Agent – takes the specialist's raw answer and writes a polished reply
# ─────────────────────────────────────────────────────────────────────────

from typing import Annotated, TypedDict, Literal

# LangChain message types used in conversations
from langchain_core.messages import AnyMessage, HumanMessage, SystemMessage

# @tool turns a plain Python function into a tool the LLM can call
from langchain_core.tools import tool

# ChatOllama connects to a locally running Ollama model
from langchain_ollama import ChatOllama

# LangGraph building blocks
from langgraph.graph import END, StateGraph     # Graph builder + END marker
from langgraph.graph.message import add_messages # Appends messages (never overwrites)
from langgraph.prebuilt import ToolNode          # Ready-made node that runs tool calls


# ─────────────────────────────────────────────────────────────────────────
# STEP 1 — Define tools for the Math Agent
# ─────────────────────────────────────────────────────────────────────────

@tool
def calculate(expression: str) -> str:
    """Evaluate a simple math expression such as '12 * (3 + 4)'."""
    # Only allow safe characters to prevent code injection attacks
    allowed = set("0123456789+-*/(). %")
    if not set(expression) <= allowed:
        return "Error: unsupported characters in expression."
    try:
        # eval() computes the result; empty dicts block access to Python builtins
        result = eval(expression, {"__builtins__": {}}, {})
        return str(result)
    except Exception as exc:
        return f"Error: {exc}"


# Tools that the Math Agent is allowed to call
MATH_TOOLS = [calculate]


# ─────────────────────────────────────────────────────────────────────────
# STEP 2 — Define the shared state
#
# Every node in the graph reads from and writes to this shared state.
# Think of it as a shared notebook that all agents can see and update.
# ─────────────────────────────────────────────────────────────────────────

class AgentState(TypedDict):
    # The full conversation history — add_messages APPENDS new messages
    # instead of replacing the whole list each time.
    messages: Annotated[list[AnyMessage], add_messages]

    # Which specialist agent should run next?
    # The Supervisor sets this value after each decision.
    next_agent: str


# ─────────────────────────────────────────────────────────────────────────
# STEP 3 — Create the LLM instances
#
# Each agent gets its OWN LLM instance.  They can have different models,
# temperatures, or system prompts.  Here we use the same model for all
# three to keep the demo simple.
# ─────────────────────────────────────────────────────────────────────────

MODEL_NAME = "llama3.2"   # Change this to any model you have pulled in Ollama

# Supervisor LLM — no tools needed, just decides who should work next
supervisor_llm = ChatOllama(model=MODEL_NAME, temperature=0)

# Math Agent LLM — knows about the calculate tool
math_llm = ChatOllama(model=MODEL_NAME, temperature=0).bind_tools(MATH_TOOLS)

# Fact Agent LLM — answers knowledge questions directly (no tools)
fact_llm = ChatOllama(model=MODEL_NAME, temperature=0)

# Writer Agent LLM — only polishes the final answer (no tools)
writer_llm = ChatOllama(model=MODEL_NAME, temperature=0)


# ─────────────────────────────────────────────────────────────────────────
# STEP 4 — Define the Supervisor node
#
# The Supervisor reads the user's question and picks ONE specialist.
# It outputs either "math_agent" or "fact_agent" — nothing else.
# It runs only once per question; there is no routing loop.
# ─────────────────────────────────────────────────────────────────────────

# System prompt that instructs the Supervisor on how to route tasks.
# The Supervisor only picks a specialist — it does NOT need to say "done"
# because after a specialist answers the graph goes straight to the Writer.
SUPERVISOR_SYSTEM = """You are a supervisor that routes tasks to the right specialist.

Given the user's question, decide which specialist should answer.
Reply with ONLY one of these exact words — nothing else:

  math_agent  — if the task involves a calculation or number
  fact_agent  — if the task is a general knowledge / factual question

Reply with a single word only."""


def supervisor_node(state: AgentState) -> AgentState:
    """
    Supervisor: reads the conversation and decides which agent runs next.
    Returns an update to 'next_agent' in the shared state.
    """
    # Build the messages to send to the Supervisor:
    # [system instructions]  +  [full conversation so far]
    supervisor_messages = [
        SystemMessage(content=SUPERVISOR_SYSTEM),
        *state["messages"],   # Unpack all messages from the conversation so far
    ]

    # Ask the Supervisor LLM to make a routing decision
    response = supervisor_llm.invoke(supervisor_messages)

    # Parse the raw text reply — strip whitespace and lowercase it
    decision = response.content.strip().lower()

    # Validate — if the model replied with something unexpected, default to fact_agent
    valid_decisions = {"math_agent", "fact_agent"}
    if decision not in valid_decisions:
        decision = "fact_agent"

    print(f"\n[Supervisor] → routing to: {decision}")

    # Update only 'next_agent'; the messages list stays unchanged
    return {"next_agent": decision}


# ─────────────────────────────────────────────────────────────────────────
# STEP 5 — Define the Math Agent node
#
# The Math Agent uses the 'calculate' tool to solve arithmetic questions.
# It may call the tool multiple times (the inner loop handles this).
# ─────────────────────────────────────────────────────────────────────────

def math_agent_node(state: AgentState) -> AgentState:
    """
    Math Agent: answers calculation questions using the calculate tool.
    After finishing, it adds its answer to the shared message list.
    """
    print("[Math Agent] working...")

    # System prompt that tells this agent to focus on math
    math_system = SystemMessage(content=(
        "You are a math specialist. "
        "Use the calculate tool to solve any arithmetic. "
        "Be concise and show the result clearly."
    ))

    # Start a local message list just for this agent's sub-conversation.
    # We include the original user question (the first HumanMessage).
    local_messages = [math_system, *state["messages"]]

    # Inner loop: let the Math Agent call tools as many times as it needs
    for _ in range(5):   # safety limit — at most 5 tool-call rounds
        response = math_llm.invoke(local_messages)
        local_messages.append(response)

        # If the LLM didn't request any tool calls, it's done with its answer
        if not getattr(response, "tool_calls", None):
            break

        # Run each requested tool call and collect results
        for call in response.tool_calls:
            if call["name"] == "calculate":
                # Some LLM versions wrap arguments in a JSON-schema dict like
                # {"type": "string", "value": "345 * 78"} instead of a plain string.
                # We unwrap it here so calculate() always receives a plain string.
                expression = call["args"].get("expression", "")
                if isinstance(expression, dict):
                    # Pull the actual value out of the schema wrapper
                    expression = expression.get("value", str(expression))
                result = calculate.invoke({"expression": expression})
                # ToolMessage links a tool result back to the original tool call ID
                from langchain_core.messages import ToolMessage
                local_messages.append(
                    ToolMessage(content=str(result), tool_call_id=call["id"])
                )

    # The last message in local_messages is the Math Agent's final answer.
    # Prepend a label so the Supervisor and Writer can identify who said it.
    final_answer = local_messages[-1]
    final_answer.content = f"[Math Agent]: {final_answer.content}"

    # Add the answer to the shared conversation state
    return {"messages": [final_answer]}


# ─────────────────────────────────────────────────────────────────────────
# STEP 6 — Define the Fact Agent node
#
# The Fact Agent answers general knowledge questions directly (no tools).
# ─────────────────────────────────────────────────────────────────────────

def fact_agent_node(state: AgentState) -> AgentState:
    """
    Fact Agent: answers general knowledge questions from its training data.
    """
    print("[Fact Agent] working...")

    fact_system = SystemMessage(content=(
        "You are a knowledgeable assistant. "
        "Answer factual questions clearly and concisely. "
        "If you are unsure, say so honestly."
    ))

    # Send the system prompt + full conversation to the Fact Agent
    response = fact_llm.invoke([fact_system, *state["messages"]])

    # Label the response so the Writer knows who provided this answer
    response.content = f"[Fact Agent]: {response.content}"

    return {"messages": [response]}


# ─────────────────────────────────────────────────────────────────────────
# STEP 7 — Define the Writer Agent node
#
# The Writer Agent reads everything in the conversation and writes a clean,
# user-friendly final answer.
# ─────────────────────────────────────────────────────────────────────────

def writer_agent_node(state: AgentState) -> AgentState:
    """
    Writer Agent: takes the raw answers from other agents and produces
    a clean, polished final response for the user.
    """
    print("[Writer Agent] polishing the final answer...")

    writer_system = SystemMessage(content=(
        "You are a writer. "
        "Read the conversation and write a clear, friendly final answer for the user. "
        "Do NOT repeat agent labels like '[Math Agent]' in your output. "
        "Just give the user a helpful, natural-sounding response."
    ))

    response = writer_llm.invoke([writer_system, *state["messages"]])

    # Label this as the final answer
    response.content = f"[Final Answer]: {response.content}"

    return {"messages": [response]}


# ─────────────────────────────────────────────────────────────────────────
# STEP 8 — Define the routing function
#
# After the Supervisor runs, this function reads 'next_agent' from the state
# and tells LangGraph which node to execute next.
# ─────────────────────────────────────────────────────────────────────────

def route_from_supervisor(state: AgentState) -> Literal["math_agent", "fact_agent"]:
    """
    Routing function called after the Supervisor node.
    Maps the Supervisor's decision to either math_agent or fact_agent.
    After the specialist runs, the graph goes directly to the Writer — no loop.
    """
    decision = state.get("next_agent", "fact_agent")
    if decision == "math_agent":
        return "math_agent"
    return "fact_agent"


# ─────────────────────────────────────────────────────────────────────────
# STEP 9 — Build the LangGraph graph
#
# Nodes are the agents.  Edges define the allowed paths between them.
# ─────────────────────────────────────────────────────────────────────────

def build_multi_agent_app():
    """Assemble all nodes and edges into a runnable LangGraph application."""

    # Create the graph; every node shares AgentState
    graph = StateGraph(AgentState)

    # ── Register nodes ────────────────────────────────────────────────────
    graph.add_node("supervisor",   supervisor_node)   # Routes to the right agent
    graph.add_node("math_agent",   math_agent_node)   # Handles math
    graph.add_node("fact_agent",   fact_agent_node)   # Handles facts
    graph.add_node("writer_agent", writer_agent_node) # Polishes final answer

    # ── Set entry point ───────────────────────────────────────────────────
    # Every request starts at the Supervisor
    graph.set_entry_point("supervisor")

    # ── Add edges ─────────────────────────────────────────────────────────
    # After the Supervisor, branch to math_agent or fact_agent
    graph.add_conditional_edges(
        "supervisor",           # source node
        route_from_supervisor,  # function that returns the next node name
        {
            "math_agent": "math_agent",  # Supervisor said "math_agent"
            "fact_agent": "fact_agent",  # Supervisor said "fact_agent"
        },
    )

    # After a specialist finishes, go DIRECTLY to the Writer.
    # This avoids an infinite Supervisor loop — once a specialist has answered
    # we know we are ready to polish and finish, no need to ask the Supervisor again.
    graph.add_edge("math_agent", "writer_agent")
    graph.add_edge("fact_agent", "writer_agent")

    # When the Writer is done, the task is complete — END the graph
    graph.add_edge("writer_agent", END)

    # compile() validates the graph structure and returns a runnable object
    return graph.compile()


# ─────────────────────────────────────────────────────────────────────────
# STEP 10 — Run the demo
# ─────────────────────────────────────────────────────────────────────────

def ask(app, question: str) -> str:
    """Send a single question to the multi-agent system and return the answer."""
    print(f"\n{'='*60}")
    print(f"Question: {question}")
    print('='*60)

    # The initial state only contains the user's message.
    # next_agent starts empty — the Supervisor will fill it in.
    initial_state = {
        "messages": [HumanMessage(content=question)],
        "next_agent": "",
    }

    # app.invoke() runs the graph until it reaches END and returns the final state
    final_state = app.invoke(initial_state)

    # The last message in the conversation is the Writer's polished answer
    final_message = final_state["messages"][-1]
    answer = final_message.content

    # Strip the "[Final Answer]: " label before printing
    clean_answer = answer.replace("[Final Answer]: ", "")
    print(f"\nAnswer: {clean_answer}\n")
    return clean_answer


if __name__ == "__main__":
    # Build the multi-agent application once
    app = build_multi_agent_app()

    # ── Example 1: math question → Math Agent handles it
    ask(app, "What is 345 multiplied by 78?")

    # ── Example 2: factual question → Fact Agent handles it
    ask(app, "What is the capital of Japan?")

    # ── Example 3: mixed question — number in the text, so the Supervisor
    #    should route it to the Math Agent to calculate the total
    ask(app, "Norway has a population of about 5.5 million. "
             "If each person drinks 2.5 cups of coffee per day, "
             "how many cups is that in total across the country?")
