# Exercise 6 - LangGraph Tool Loop Agent

## Goal
Build a minimal LangGraph agent that routes between:
1. A model node.
2. A tool node.

This exercise is aligned with:
- Part4_langgraph_agent.py

## Prerequisites
- Ollama server running: `ollama serve`
- Model pulled once: `ollama pull llama3.2`
- Python packages:
  - `pip install langgraph langchain-core langchain-ollama`

## Tutorial Steps
1. Open `startscripts/ex6_start.py`.
2. Define a typed state with `messages` and `add_messages` reducer.
3. Add `call_model` node and `route_after_model` function.
4. Register `ToolNode([...])` for calculator/time tools.
5. Compile graph and run sample questions.

## Tasks
- Build graph entry point at `model`.
- Add conditional route:
  - `tools` when model requests tool calls
  - `END` otherwise
- Add edge from `tools` back to `model`.

## Acceptance Criteria
- Graph performs at least one tool round-trip.
- Final message is printed for each question.
- Code remains short and beginner-readable.

## Start Script
- `startscripts/ex6_start.py`

## Reference Solution
- `solutions/ex6_solution.py`

## Run
```powershell
python startscripts/ex6_start.py
# or
python solutions/ex6_solution.py
```
