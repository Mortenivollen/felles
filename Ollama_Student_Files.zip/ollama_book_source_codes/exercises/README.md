# Exercises Overview

Core course docs:
- [../course_docs/workspace_oversikt.md](../course_docs/workspace_oversikt.md) — folder and file overview
- [../course_docs/undervisningsplan_detaljert.md](../course_docs/undervisningsplan_detaljert.md) — detailed 3-day teaching plan
- [../course_docs/undervisningsplan_detaljert.docx](../course_docs/undervisningsplan_detaljert.docx) — Word version

- [exercise1.md](exercise1.md) — Prompting with Ollama SDK
- [exercise2.md](exercise2.md) — LangChain pipeline with structured JSON output
- [exercise3.md](exercise3.md) — Minimal CLI RAG over a local document
- [exercise4.md](exercise4.md) — Persona model and categorizer
- [exercise5.md](exercise5.md) — LangChain tool agent
- [exercise6.md](exercise6.md) — LangGraph tool loop agent
- [exercise7.md](exercise7.md) — Supervisor and specialist multi-agent
- [exercise8.md](exercise8.md) — MCP tools with Ollama agent

DOCX versions:
- [exercise1.docx](exercise1.docx)
- [exercise2.docx](exercise2.docx)
- [exercise3.docx](exercise3.docx)
- [exercise4.docx](exercise4.docx)
- [exercise5.docx](exercise5.docx)
- [exercise6.docx](exercise6.docx)
- [exercise7.docx](exercise7.docx)
- [exercise8.docx](exercise8.docx)

Companion docs:
- [script_mapping.md](script_mapping.md) — script-to-exercise mapping table
- [micro_exercises.md](micro_exercises.md) — short 15-20 minute practice tasks

Starters and solutions:
- Starters for exercises 4-8 are in [../startscripts/](../startscripts/)
- Solutions for exercises 1-8 are in [../solutions/](../solutions/)

Quick launcher:
- Run [../start_exercises.py](../start_exercises.py) to select and run starter/solution scripts.
- Run [../generate_exercise_docx.py](../generate_exercise_docx.py) to regenerate exercise4-8 DOCX files.
