# Micro Exercises (15-20 Minutes Each)

These mini tasks are designed for quick beginner practice blocks.

## Block A - Ollama Basics
1. Change prompt style in Exercise 1 and compare concise vs detailed outputs.
2. Add one command-line argument to choose model name.
3. Add a friendly error message when server is not reachable.

## Block B - LangChain Basics
1. In Exercise 2, add one extra JSON key: confidence (0-100).
2. Add a fallback path when JSON parsing fails.
3. Try temperature 0.0 and 0.6, compare output stability.

## Block C - RAG Basics
1. In Exercise 3, change chunk_size from 800 to 500 and compare retrieval.
2. Print top-2 chunk sources before answering.
3. Add one guardrail sentence in prompt: answer only from context.

## Block D - Persona and Categorization
1. In Exercise 4, change persona from travel helper to study coach.
2. Add one new category and enforce alphabetical sorting.
3. Compare output quality between base model and custom model.

## Block E - Tool Agents
1. In Exercise 5, add a new tool that returns current weekday.
2. Validate calculator input with one extra forbidden pattern.
3. Run one question that should not use tools and verify behavior.

## Block F - LangGraph Routing
1. In Exercise 6, print route decisions (tools vs end) for each turn.
2. Add one more sample prompt that forces a tool call.
3. Add a hard limit for loop rounds to avoid runaway calls.

## Block G - Multi-Agent
1. In Exercise 7, add a fourth specialist for short summaries.
2. Improve supervisor routing prompt to reduce mis-routing.
3. Compare final answer with and without writer node.

## Block H - MCP Tools
1. In Exercise 8, print discovered tool names before invoke.
2. Make MCP URL configurable from command line.
3. Add user-friendly fallback text when MCP endpoint is unavailable.

## Optional Assessment Rubric
- 1 point: code runs
- 1 point: error handling works
- 1 point: output format is clear
- 1 point: change is explained in one sentence
- 1 point: student can demo it live
