# Exercise 4 - Persona Model and Categorizer

## Goal
Build a beginner script that:
1. Creates a local custom model with a simple system prompt.
2. Uses that model to categorize a short list of items.

This exercise is aligned with:
- Part1_app3.py (create custom model)
- Part1_app4.py and categorizer.py (categorization prompt)

## Prerequisites
- Ollama server running: `ollama serve`
- Model pulled once: `ollama pull llama3.2`
- Python package: `pip install ollama`

## Tutorial Steps
1. Open `startscripts/ex4_start.py`.
2. Fill in `build_custom_model()` to call `ollama.create(...)`.
3. Fill in `categorize_items(...)` to call `ollama.generate(...)`.
4. Run the script and inspect the grouped output.
5. Change the persona text and compare output style.

## Tasks
- Create model name `travel_helper` derived from `llama3.2`.
- Use a system message that asks for concise and practical responses.
- Categorize the provided item list into 5 sections:
  - Clothing
  - Toiletries
  - Electronics
  - Documents
  - Miscellaneous
- Keep items alphabetized inside each section.

## Acceptance Criteria
- Script creates the custom model (or reuses it if already present).
- Script prints categorized output in readable sections.
- Script handles errors cleanly when Ollama is unavailable.

## Start Script
- `startscripts/ex4_start.py`

## Reference Solution
- `solutions/ex4_solution.py`

## Run
```powershell
python startscripts/ex4_start.py
# or
python solutions/ex4_solution.py
```
