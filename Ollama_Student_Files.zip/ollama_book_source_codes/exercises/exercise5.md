# Exercise 5 - LangChain Tool Agent

## Goal
Create a tool-using agent with LangChain and Ollama that can:
1. Return local time.
2. Evaluate simple math expressions safely.

This exercise is aligned with:
- Part4_langchain_agent_tools.py

## Prerequisites
- Ollama server running: `ollama serve`
- Model pulled once: `ollama pull llama3.2`
- Python packages:
  - `pip install langchain-core langchain-ollama`

## Tutorial Steps
1. Open `startscripts/ex5_start.py`.
2. Complete the `@tool` functions for time and calculator.
3. Bind tools with `llm.bind_tools(...)`.
4. Implement one tool-call loop:
   - Ask LLM
   - Execute requested tools
   - Ask LLM again with tool results
5. Run example questions.

## Tasks
- Implement `get_current_time` tool.
- Implement safe `calculate` tool with allow-list characters.
- Add `run_turn(question)` that executes one full tool cycle.
- Test with:
  - `What time is it?`
  - `What is (1250 * 19) / 100?`

## Acceptance Criteria
- Agent uses tools when required.
- Agent answers direct knowledge questions without tool usage.
- Calculator rejects unsupported characters.

## Start Script
- `startscripts/ex5_start.py`

## Reference Solution
- `solutions/ex5_solution.py`

## Run
```powershell
python startscripts/ex5_start.py
# or
python solutions/ex5_solution.py
```
