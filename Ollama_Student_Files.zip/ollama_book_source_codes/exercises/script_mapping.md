# Script to Exercise Mapping

This table connects the workspace demo scripts to the recommended beginner exercises.

| Script | Focus | Recommended Exercise |
|---|---|---|
| Part1_app1.py | Basic Ollama REST streaming | Exercise 1 |
| Part1_app2.py | Basic Ollama SDK chat usage | Exercise 1 |
| Part1_app3.py | Create custom persona model | Exercise 4 |
| Part1_app4.py | Prompt-based list categorization | Exercise 4 |
| categorizer.py | Categorizer prompt patterns | Exercise 4 |
| Part2_app1.py | LangChain prompt/chain basics | Exercise 2 |
| Part2_app2.py | Preflight and robust setup flow | Exercise 2 |
| Part2_app3.py | Streamlit app with Ollama | Exercise 2 (optional UI extension) |
| part3_rag1.py | RAG fundamentals | Exercise 3 |
| Part3_rag2.py | LangChain splitter + embeddings RAG | Exercise 3 |
| Part3_rag3_streamlit.py | Streamlit RAG interaction | Exercise 3 (optional UI extension) |
| Part4_langchain_agent_tools.py | Tool-using agent loop | Exercise 5 |
| Part4_langgraph_agent.py | LangGraph model/tool routing | Exercise 6 |
| Part5_multi_agent.py | Supervisor and specialist agents | Exercise 7 |
| Part5_mcp_ollama_langchain_langgraph.py | MCP tools with agent | Exercise 8 |
| itil_log_agent.py | End-to-end multi-agent + RAG | Exercise 7 then 8 (capstone) |
| Part1_web_search_agent.py | Web-search tool usage | Exercise 5 (extension) |
| gpu_verify.py | Environment verification and diagnostics | Warm-up utility before all exercises |

## Suggested Learning Order
1. Exercise 1
2. Exercise 2
3. Exercise 3
4. Exercise 4
5. Exercise 5
6. Exercise 6
7. Exercise 7
8. Exercise 8
