# Exercise 7 - Supervisor and Specialist Multi-Agent

## Goal
Create a simple multi-agent workflow with three roles:
1. Supervisor (router)
2. Specialist (math or fact)
3. Writer (final polished answer)

This exercise is aligned with:
- Part5_multi_agent.py

## Prerequisites
- Ollama server running: `ollama serve`
- Model pulled once: `ollama pull llama3.2`
- Python packages:
  - `pip install langgraph langchain-core langchain-ollama`

## Tutorial Steps
1. Open `startscripts/ex7_start.py`.
2. Implement supervisor decision logic (`math_agent` vs `fact_agent`).
3. Implement specialist nodes.
4. Add writer node to polish output.
5. Connect linear graph paths and run examples.

## Tasks
- Route to math agent when question contains arithmetic intent.
- Route to fact agent for general knowledge questions.
- Always pass specialist output through writer node.

## Acceptance Criteria
- Different questions route to different specialists.
- Final output comes from writer node.
- Graph ends cleanly without loops.

## Start Script
- `startscripts/ex7_start.py`

## Reference Solution
- `solutions/ex7_solution.py`

## Run
```powershell
python startscripts/ex7_start.py
# or
python solutions/ex7_solution.py
```
