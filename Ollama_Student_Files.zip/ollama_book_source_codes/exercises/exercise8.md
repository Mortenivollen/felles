# Exercise 8 - MCP Tools with Ollama Agent (Stretch Beginner)

## Goal
Connect an Ollama-based agent to an MCP server and let it use discovered tools.

This exercise is aligned with:
- Part5_mcp_ollama_langchain_langgraph.py

## Prerequisites
- Ollama server running: `ollama serve`
- Model pulled once: `ollama pull llama3.2`
- Python packages:
  - `pip install langchain langchain-ollama langchain-mcp-adapters`
- Optional environment variable:
  - `REMOTE_MCP_URL` (defaults to Microsoft demo endpoint)

## Tutorial Steps
1. Open `startscripts/ex8_start.py`.
2. Create `MultiServerMCPClient` with one server entry.
3. Fetch tool list with `await client.get_tools()`.
4. Create a LangChain agent and invoke with one query.
5. Print final answer and tool count.

## Tasks
- Use async function `run_demo()`.
- Read MCP URL from environment variable with a default.
- Show a friendly error when MCP server is unreachable.

## Acceptance Criteria
- Script can list MCP tools.
- Agent returns an answer for the sample query.
- Failures are explained with actionable text.

## Start Script
- `startscripts/ex8_start.py`

## Reference Solution
- `solutions/ex8_solution.py`

## Run
```powershell
python startscripts/ex8_start.py
# or
python solutions/ex8_solution.py
```
