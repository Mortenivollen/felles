import ollama  # Python SDK for interacting with a local Ollama server

# Define a lightweight "modelfile"-style configuration:
# - PARAMETER: sets default generation params (e.g., temperature)
# - SYSTEM: sets the default system prompt/instructions for the model
modelfile = """
PARAMETER temperature 0.3
SYSTEM You are Peter, an intelligent assistant known for providing clear, concise, and informative answers to questions.
"""

# Create a local derived model named "smartassistant" from base "llama3.2".
# Notes:
# - Ensure Ollama is running (`ollama serve`) and the base model is pulled (`ollama pull llama3.2`).
# - 'from_' specifies the base model.
# - Passing our modelfile string via the 'system' field (per this repo’s pattern) to configure params + system.
ollama.create(model="smartassistant", system=modelfile, from_="llama3.2")

# Generate a response from the newly created model using a simple prompt.
# Returns a dict with keys like: 'model', 'created_at', 'response', 'done', etc.
res = ollama.generate(model="smartassistant", prompt="what is your name")

# Print only the text portion of the generation result.
print(res["response"])
