# itil_log_agent.py
#
# ═══════════════════════════════════════════════════════════════════════════
#  ADVANCED BEGINNER DEMO — IT Log Analysis with Multi-Agent Orchestration
#  using Ollama + LangChain + LangGraph
# ═══════════════════════════════════════════════════════════════════════════
#
#  WHAT THIS SCRIPT DOES:
#  ─────────────────────
#  1. Creates a realistic sample IT log file on disk (so you always have
#     something to analyse even on a fresh machine).
#  2. Reads that log file with a LangChain TOOL.
#  3. Fetches ITIL concept definitions from the official web page with
#     another TOOL, so the LLMs can speak proper ITIL language.
#  4. Searches and downloads ITIL docs from the web into a local folder,
#     then indexes them into a local Chroma RAG store.
#  5. Three specialist AGENTS then each do ONE job:
#        • ITIL Translator  – rewrites the raw log in ITIL terminology
#        • Criticality Agent – rates how severe / urgent the incident is
#        • Team Router Agent – decides which IT team should own this
#  6. A SUPERVISOR reads all three specialist reports and writes a single,
#     clear, actionable briefing for the on-call engineer.
#
#  FLOW (linear — no loops, no recursion risk):
#
#   START
#     │
#     ▼
#  ┌───────────────┐   tool: read_log_file + fetch_itil_concepts
#  │  Data Loader  │────────────────────────────────────────────► base context loaded
#  └───────┬───────┘
#          │
#       ▼
#  ┌────────────────────┐  tool: search_and_download_itil_docs
#  │  RAG Prep (tools)  │  finds ITIL pages, saves them locally
#  └──────────┬─────────┘
#             │
#             ▼
#  ┌────────────────────┐  local Chroma + OllamaEmbeddings
#  │  RAG Retrieve      │  injects relevant ITIL chunks into prompts
#  └──────────┬─────────┘
#             │
#             ▼
#  ┌────────────────┐
#  │ ITIL Translator│  Summarises log using ITIL vocab + RAG context
#  └────────┬───────┘
#           │
#           ▼
#  ┌──────────────────┐
#  │Criticality Agent │  Rates severity P1-P4 and explains business impact
#  └────────┬─────────┘
#           │
#           ▼
#  ┌──────────────────┐
#  │Team Router Agent │  Recommends which team should handle it and why
#  └────────┬─────────┘
#           │
#           ▼
#  ┌──────────────────────┐
#  │ Supervisor (final)   │  Writes the final briefing for the engineer
#  └────────┬─────────────┘
#           │
#          END
#
#  KEY CONCEPTS FOR BEGINNERS:
#  ──────────────────────────
#  • Tool     : a plain Python function the LLM can "call" to get data
#               (read a file, fetch a web page, query a database …)
#  • Node     : one step in the LangGraph workflow — usually calls an LLM
#  • Edge     : the arrow connecting two nodes (fixed or conditional)
#  • State    : a shared dictionary every node can read from and write to
#  • Supervisor: coordinates the other agents and produces the final output
#
#  REQUIREMENTS:
#  ─────────────
#  pip install langchain langchain-ollama langchain-core langgraph
#              langchain-community langchain-text-splitters chromadb requests
#  Ollama must be running:   ollama serve
#  Model must be available:  ollama pull llama3.2
#  Embeddings model:         ollama pull mxbai-embed-large
# ═══════════════════════════════════════════════════════════════════════════

import json
import re
import shutil
import textwrap
from datetime import datetime
from pathlib import Path
from typing import Annotated, TypedDict
from urllib.parse import quote

import requests                                      # for fetching web pages
from langchain_core.documents import Document
from langchain_core.messages import AnyMessage, HumanMessage, SystemMessage
from langchain_core.tools import tool                # @tool decorator
from langchain_community.vectorstores import Chroma
from langchain_ollama import ChatOllama, OllamaEmbeddings  # local LLM + embeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langgraph.graph import END, StateGraph          # graph builder
from langgraph.graph.message import add_messages     # smart message appender


# ═══════════════════════════════════════════════════════════════════════════
#  SECTION 1 — CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════

# Which Ollama model to use.  Change to "mistral", "phi3", etc. if needed.
MODEL_NAME = "llama3.2"

# Embedding model used for local RAG indexing/retrieval.
# Pull once with: ollama pull mxbai-embed-large
EMBED_MODEL = "mxbai-embed-large"

# Folder where log files live.  We create it automatically if it doesn't exist.
LOG_FOLDER = Path("logs")

# The specific log file we want to analyse.
LOG_FILE = LOG_FOLDER / "app_errors.log"

# Public ITIL reference page (Wikipedia — always available, no login needed).
# We fetch this at runtime so the agents can use real ITIL vocabulary.
ITIL_URL = "https://en.wikipedia.org/wiki/ITIL"

# Folder where downloaded ITIL documents are stored as .txt files
ITIL_DOCS_FOLDER = Path("itil_docs")

# Folder used by Chroma to store local vector embeddings persistently
RAG_DB_FOLDER = Path("rag_store") / "itil"

# Toggle for demo behavior:
#   True  -> rebuild the vector store on every run (deterministic teaching mode)
#   False -> reuse existing store when available (faster repeated runs)
REBUILD_RAG_EACH_RUN = False


# ═══════════════════════════════════════════════════════════════════════════
#  SECTION 2 — CREATE A SAMPLE LOG FILE
#
#  In a real project the log file already exists on disk.
#  Here we generate one so the demo always works out of the box.
#  The log simulates a sequence of errors on a production e-commerce system.
# ═══════════════════════════════════════════════════════════════════════════

SAMPLE_LOG = """\
2026-03-17 01:12:03 ERROR  [payment-service]   Connection refused: postgres://db-prod:5432
2026-03-17 01:12:04 ERROR  [payment-service]   Retry 1/3 — waiting 2 s …
2026-03-17 01:12:06 ERROR  [payment-service]   Retry 2/3 — waiting 4 s …
2026-03-17 01:12:10 ERROR  [payment-service]   Retry 3/3 — waiting 8 s …
2026-03-17 01:12:18 CRITICAL [payment-service] All retries exhausted.  Payments OFFLINE.
2026-03-17 01:12:19 ERROR  [api-gateway]       Upstream 503 from payment-service
2026-03-17 01:12:19 WARN   [api-gateway]       Circuit-breaker OPEN for payment-service
2026-03-17 01:12:20 ERROR  [order-service]     Cannot confirm orders: payment unavailable
2026-03-17 01:13:05 ERROR  [monitoring]        Health-check FAILED for db-prod (no response)
2026-03-17 01:13:06 ALERT  [monitoring]        PagerDuty alert #INC-20483 triggered
2026-03-17 01:14:00 INFO   [db-prod]           Failover initiated — switching to db-replica
2026-03-17 01:16:44 INFO   [db-prod]           Replica promoted successfully
2026-03-17 01:16:45 INFO   [payment-service]   Database connection restored
2026-03-17 01:16:46 INFO   [payment-service]   Service resumed — processing backlog (412 orders)
2026-03-17 01:18:30 INFO   [api-gateway]       Circuit-breaker CLOSED — payment-service healthy
2026-03-17 01:19:00 INFO   [order-service]     Backlog processed.  All systems operational.
"""


def create_sample_log() -> None:
    """
    Create the logs/ folder and write a sample log file if it doesn't exist.
    This means the demo works on a fresh machine with zero setup.
    """
    # Create the directory; ok_exist=True means no error if it already exists
    LOG_FOLDER.mkdir(parents=True, exist_ok=True)

    if not LOG_FILE.exists():
        LOG_FILE.write_text(SAMPLE_LOG, encoding="utf-8")
        print(f"[Setup] Created sample log → {LOG_FILE}")
    else:
        print(f"[Setup] Using existing log → {LOG_FILE}")


def _safe_filename(name: str) -> str:
    """Convert a title into a filesystem-safe filename."""
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", name.strip())
    return cleaned[:80].strip("_") or "document"


# ═══════════════════════════════════════════════════════════════════════════
#  SECTION 3 — TOOLS
#
#  A TOOL is a plain Python function decorated with @tool.
#  LangChain/LangGraph makes these available to LLMs so they can retrieve
#  real data instead of hallucinating it from training data.
#
#  TIP: The docstring of a @tool function is what the LLM reads to decide
#       whether to call the tool.  Write it clearly!
# ═══════════════════════════════════════════════════════════════════════════

@tool
def read_log_file(file_path: str) -> str:
    """
    Read and return the full content of an IT log file from disk.
    Use this tool to load the raw log text before analysing it.
    file_path should be the path to the log file, e.g. 'logs/app_errors.log'.
    """
    path = Path(file_path)

    # Safety check: make sure the file actually exists
    if not path.exists():
        return f"Error: file not found — {file_path}"

    # Safety check: refuse to read very large files to avoid flooding the LLM
    max_bytes = 20_000   # 20 KB — more than enough for a typical incident log
    size = path.stat().st_size
    if size > max_bytes:
        return (
            f"Error: file too large ({size} bytes). "
            f"Only files up to {max_bytes} bytes are supported."
        )

    return path.read_text(encoding="utf-8")


@tool
def fetch_itil_concepts(url: str = ITIL_URL) -> str:
    """
    Fetch a short summary of ITIL concepts from a web page.
    Returns the first ~3000 characters of the page's visible text.
    Use this tool to ground the analysis in real ITIL terminology.
    """
    try:
        # Set a browser-like User-Agent header so Wikipedia doesn't block us
        headers = {"User-Agent": "Mozilla/5.0 (compatible; ItilLogAgent/1.0)"}

        # stream=False means we wait for the full response before processing
        response = requests.get(url, headers=headers, timeout=10)

        # Raise an exception if the server returned an HTTP error (4xx / 5xx)
        response.raise_for_status()

        # The web page contains HTML tags.  We do a very simple text extraction:
        # remove everything inside < … > brackets using a basic approach.
        # (For production code you would use Beautiful Soup instead.)
        raw_html = response.text
        import re
        # Remove script and style blocks entirely
        raw_html = re.sub(r"<(script|style)[^>]*>.*?</(script|style)>", "", raw_html, flags=re.S)
        # Remove all remaining HTML tags
        plain_text = re.sub(r"<[^>]+>", " ", raw_html)
        # Collapse whitespace
        plain_text = re.sub(r"\s+", " ", plain_text).strip()

        # Return only the first 3000 characters — enough context for the LLM
        return plain_text[:3000]

    except requests.exceptions.ConnectionError:
        # No internet connection — return a built-in fallback summary
        return (
            "ITIL (Information Technology Infrastructure Library) is a framework "
            "of best practices for IT service management (ITSM). Key concepts: "
            "Incident Management (restore service ASAP), Problem Management "
            "(find root cause), Change Management (control changes), "
            "Configuration Management (track CIs), Service Level Agreements (SLAs), "
            "Priority levels P1 (Critical) P2 (High) P3 (Medium) P4 (Low), "
            "CMDB (Configuration Management Database), "
            "Major Incident (business-wide impact requiring war-room response)."
        )
    except Exception as exc:
        return f"Error fetching ITIL concepts: {exc}"


@tool
def search_and_download_itil_docs(query: str = "ITIL incident management", limit: int = 6) -> str:
    """
    Search public ITIL-related pages on Wikipedia and download them as local .txt files.
    Returns a JSON list with title/url/file_path for each downloaded document.
    """
    ITIL_DOCS_FOLDER.mkdir(parents=True, exist_ok=True)

    # Wikipedia Search API endpoint
    search_url = "https://en.wikipedia.org/w/api.php"

    try:
        # 1) Search pages related to the query
        search_params = {
            "action": "query",
            "list": "search",
            "srsearch": query,
            "srlimit": max(1, min(limit, 10)),  # keep demo small and quick
            "format": "json",
        }
        search_resp = requests.get(search_url, params=search_params, timeout=12)
        search_resp.raise_for_status()
        search_items = search_resp.json().get("query", {}).get("search", [])

        if not search_items:
            return "[]"

        downloaded = []

        # 2) For each page title, fetch plain-text extract and store it locally
        for item in search_items:
            title = item.get("title", "Untitled")

            extract_params = {
                "action": "query",
                "prop": "extracts",
                "explaintext": 1,
                "titles": title,
                "format": "json",
            }
            extract_resp = requests.get(search_url, params=extract_params, timeout=12)
            extract_resp.raise_for_status()

            pages = extract_resp.json().get("query", {}).get("pages", {})
            page_data = next(iter(pages.values()), {})
            extract_text = page_data.get("extract", "")

            if not extract_text.strip():
                continue

            file_name = _safe_filename(title) + ".txt"
            file_path = ITIL_DOCS_FOLDER / file_name

            # Save with a tiny metadata header for transparency
            wiki_url = f"https://en.wikipedia.org/wiki/{quote(title.replace(' ', '_'))}"
            file_path.write_text(
                f"Title: {title}\nSource: {wiki_url}\n\n{extract_text}",
                encoding="utf-8",
            )

            downloaded.append({
                "title": title,
                "url": wiki_url,
                "file_path": str(file_path),
            })

        return json.dumps(downloaded)

    except Exception as exc:
        return json.dumps([{
            "title": "fallback",
            "url": ITIL_URL,
            "file_path": "",
            "error": str(exc),
        }])


def build_local_itil_rag_store(rebuild: bool = True) -> Chroma:
    """
    Build or load a local Chroma vector store from downloaded ITIL docs.
    Returns a ready-to-query Chroma object.

    rebuild=True  -> delete old store and index documents again
    rebuild=False -> reuse existing store if found, otherwise build it
    """
    embeddings = OllamaEmbeddings(model=EMBED_MODEL)

    # Fast path: reuse existing store if caller requested reuse
    if not rebuild and RAG_DB_FOLDER.exists() and any(RAG_DB_FOLDER.iterdir()):
        return Chroma(
            persist_directory=str(RAG_DB_FOLDER),
            embedding_function=embeddings,
            collection_name="itil_docs",
        )

    # Rebuild path: start from a clean folder
    if RAG_DB_FOLDER.exists():
        shutil.rmtree(RAG_DB_FOLDER)
    RAG_DB_FOLDER.mkdir(parents=True, exist_ok=True)

    docs_for_index: list[Document] = []
    splitter = RecursiveCharacterTextSplitter(chunk_size=900, chunk_overlap=150)

    # If no downloaded files exist, index a fallback ITIL summary
    doc_files = sorted(ITIL_DOCS_FOLDER.glob("*.txt"))
    if not doc_files:
        fallback_text = fetch_itil_concepts.invoke({"url": ITIL_URL})
        doc_files = [ITIL_DOCS_FOLDER / "itil_fallback.txt"]
        doc_files[0].write_text(fallback_text, encoding="utf-8")

    for file_path in doc_files:
        full_text = file_path.read_text(encoding="utf-8")
        chunks = splitter.split_text(full_text)
        for chunk in chunks:
            docs_for_index.append(
                Document(page_content=chunk, metadata={"source": str(file_path)})
            )

    return Chroma.from_documents(
        documents=docs_for_index,
        embedding=embeddings,
        persist_directory=str(RAG_DB_FOLDER),
        collection_name="itil_docs",
    )


def retrieve_itil_rag_context(log_text: str, k: int = 4, rebuild: bool = True) -> str:
    """
    Retrieve the top-k ITIL chunks from the local vector store relevant to the log.
    """
    vectorstore = build_local_itil_rag_store(rebuild=rebuild)
    query = (
        "Find ITIL guidance relevant to this incident log. "
        "Focus on incident management, prioritization, escalation, and resolver groups.\n\n"
        f"LOG:\n{log_text[:1500]}"
    )

    matches = vectorstore.similarity_search(query, k=k)
    if not matches:
        return ""

    rendered_chunks = []
    for i, match in enumerate(matches, start=1):
        source = Path(match.metadata.get("source", "unknown")).name
        rendered_chunks.append(f"[RAG Chunk {i} | {source}]\n{match.page_content}")
    return "\n\n".join(rendered_chunks)


# ═══════════════════════════════════════════════════════════════════════════
#  SECTION 4 — SHARED STATE
#
#  Every node in the graph reads from and writes to this shared state object.
#  Think of it as a shared whiteboard that all agents can see.
#
#  Using TypedDict gives us type hints so our editor can catch typos.
# ═══════════════════════════════════════════════════════════════════════════

class AnalysisState(TypedDict):
    # The full conversation/message history.
    # Annotated[…, add_messages] tells LangGraph to APPEND new messages
    # rather than replacing the entire list — very important!
    messages: Annotated[list[AnyMessage], add_messages]

    # Raw log text loaded from disk by the read_log_file tool
    log_content: str

    # ITIL reference text fetched from the web
    itil_context: str

    # Extra ITIL context retrieved from a local RAG store
    rag_context: str

    # JSON list describing which documents were downloaded for RAG indexing
    rag_doc_list: str

    # Output from the ITIL Translator agent
    itil_summary: str

    # Output from the Criticality Agent
    criticality_report: str

    # Output from the Team Router Agent
    team_recommendation: str

    # The final briefing written by the Supervisor
    final_briefing: str


# ═══════════════════════════════════════════════════════════════════════════
#  SECTION 5 — LLM INSTANCES
#
#  We create one ChatOllama instance per agent.  They all use the same model
#  here, but in a real system each agent might use a different model suited
#  to its task (e.g. a fast small model for routing, a large one for writing).
# ═══════════════════════════════════════════════════════════════════════════

# temperature=0 → deterministic, no creativity (good for analysis tasks)
# temperature=0.3 → slight creativity (good for writing the final briefing)

itil_llm        = ChatOllama(model=MODEL_NAME, temperature=0)
criticality_llm = ChatOllama(model=MODEL_NAME, temperature=0)
team_llm        = ChatOllama(model=MODEL_NAME, temperature=0)
supervisor_llm  = ChatOllama(model=MODEL_NAME, temperature=0.3)


# ═══════════════════════════════════════════════════════════════════════════
#  SECTION 6 — NODES (AGENTS & SUPERVISOR)
#
#  Each node is a Python function that:
#    1. Receives the current state as its only argument
#    2. Does something (calls an LLM, a tool, or both)
#    3. Returns a PARTIAL state update (a dict with only the keys it changed)
#
#  LangGraph merges the returned dict into the shared state automatically.
# ═══════════════════════════════════════════════════════════════════════════

# ─────────────────────────────────────────────────────────────────────────
# NODE 1 — Data Loader
#
# This node is NOT backed by an LLM.  It simply calls our two tools
# (read_log_file and fetch_itil_concepts) and stores the results in
# the shared state so every following node can use them.
#
# WHY a separate loader node?
#   Keeping data loading separate from analysis makes each node do ONE thing.
#   This is the Single Responsibility Principle — great for debugging.
# ─────────────────────────────────────────────────────────────────────────

def data_loader_node(state: AnalysisState) -> dict:
    """Load the log file and ITIL reference text into shared state."""

    print("\n[Data Loader] Reading log file and ITIL documentation …")

    # Call the read_log_file tool directly (no LLM needed here)
    log_text = read_log_file.invoke({"file_path": str(LOG_FILE)})

    # Call the fetch_itil_concepts tool to get real ITIL vocabulary
    itil_text = fetch_itil_concepts.invoke({"url": ITIL_URL})

    # Build a tiny local ITIL knowledge base for RAG:
    # 1) search + download docs
    # 2) index docs in Chroma
    # 3) retrieve chunks relevant to this log
    rag_doc_list = search_and_download_itil_docs.invoke({
        "query": "ITIL incident management problem management change management SLA",
        "limit": 6,
    })
    rag_context = retrieve_itil_rag_context(
        log_text,
        k=4,
        rebuild=REBUILD_RAG_EACH_RUN,
    )

    print(f"[Data Loader] Log loaded ({len(log_text)} chars)")
    print(f"[Data Loader] ITIL context loaded ({len(itil_text)} chars)")
    print(f"[Data Loader] RAG context loaded ({len(rag_context)} chars)")

    # Return only the keys we changed — LangGraph merges this into state
    return {
        "log_content": log_text,
        "itil_context": itil_text,
        "rag_context": rag_context,
        "rag_doc_list": rag_doc_list,
    }


# ─────────────────────────────────────────────────────────────────────────
# NODE 2 — ITIL Translator Agent
#
# Reads the raw log and the ITIL reference, then rewrites the log events
# using proper ITIL terminology:
#   • Turns "payment-service OFFLINE" into an Incident record
#   • Identifies the Configuration Items (CIs) affected
#   • Notes whether a Major Incident threshold has been crossed
#   • Mentions any SLA implications
# ─────────────────────────────────────────────────────────────────────────

def itil_translator_node(state: AnalysisState) -> dict:
    """Translate raw log content into ITIL-compliant incident terminology."""

    print("\n[ITIL Translator] Analysing log in ITIL terms …")

    # System prompt — tells the LLM exactly what role to play and what to produce
    system = SystemMessage(content=(
        "You are an ITIL-certified IT Service Manager. "
        "Your job is to read a raw application log and rewrite it as a structured "
        "ITIL Incident record using correct ITIL v4 terminology.\n\n"
        "Use the ITIL reference below to ground your vocabulary.\n\n"
        "Your output MUST contain:\n"
        "  • Incident Title\n"
        "  • Affected Configuration Items (CIs)\n"
        "  • Incident Timeline (key events in ITIL language)\n"
        "  • SLA considerations\n"
        "  • Whether this qualifies as a Major Incident (yes/no + reason)\n\n"
        "Be concise — aim for 200-300 words."
    ))

    # Human message — gives the agent the actual data to work with
    human = HumanMessage(content=(
        f"## ITIL Reference\n{state['itil_context']}\n\n"
        f"## Extra ITIL Context from Local RAG\n{state['rag_context']}\n\n"
        f"## Raw Log\n{state['log_content']}"
    ))

    # Invoke the LLM and capture its response
    response = itil_llm.invoke([system, human])

    print("[ITIL Translator] Done.")

    # Store the ITIL summary and also add it to the message history
    # so the next agents (and the Supervisor) can read it
    return {
        "itil_summary": response.content,
        "messages": [response],
    }


# ─────────────────────────────────────────────────────────────────────────
# NODE 3 — Criticality Agent
#
# Reads the ITIL summary and the raw log, then assigns a priority level
# (P1 / P2 / P3 / P4) using the ITIL priority matrix:
#
#   Impact × Urgency = Priority
#   P1 = Critical  (major business impact, act immediately)
#   P2 = High      (significant impact, act within 2 hours)
#   P3 = Medium    (moderate impact, act within 8 hours)
#   P4 = Low       (minimal impact, act within 24 hours)
# ─────────────────────────────────────────────────────────────────────────

def criticality_agent_node(state: AnalysisState) -> dict:
    """Assess the severity and business impact of the incident."""

    print("\n[Criticality Agent] Assessing severity …")

    system = SystemMessage(content=(
        "You are an ITIL Incident Manager specialising in impact and urgency assessment.\n\n"
        "Using the ITIL priority matrix (Impact × Urgency), assign a priority:\n"
        "  P1 = Critical  — major business impact, immediate action required\n"
        "  P2 = High      — significant impact, action within 2 hours\n"
        "  P3 = Medium    — moderate impact, action within 8 hours\n"
        "  P4 = Low       — minimal impact, action within 24 hours\n\n"
        "Your output MUST contain:\n"
        "  • Priority Level (P1 / P2 / P3 / P4)\n"
        "  • Impact assessment (what and how many users/systems are affected)\n"
        "  • Urgency assessment (how fast does this need to be resolved?)\n"
        "  • Business risk if unresolved (revenue loss, reputation, compliance)\n"
        "  • Recommended Response Time\n\n"
        "Be concise — aim for 150-200 words."
    ))

    human = HumanMessage(content=(
        f"## ITIL Incident Summary\n{state['itil_summary']}\n\n"
        f"## Extra ITIL Context from Local RAG\n{state['rag_context']}\n\n"
        f"## Raw Log (for reference)\n{state['log_content']}"
    ))

    response = criticality_llm.invoke([system, human])

    print("[Criticality Agent] Done.")

    return {
        "criticality_report": response.content,
        "messages": [response],
    }


# ─────────────────────────────────────────────────────────────────────────
# NODE 4 — Team Router Agent
#
# Decides which IT team (or combination of teams) should own this incident.
# Common teams in an ITIL organisation:
#   • Service Desk         – first line, triage and communication
#   • Database Team        – DBA engineers, DB servers and storage
#   • Platform / Infra     – servers, virtualisation, cloud infrastructure
#   • Application Support  – app servers, microservices, deployments
#   • Network Team         – firewalls, load balancers, connectivity
#   • Security / SIRT      – security incidents and breaches
#   • Change Advisory Board (CAB) – if a change is needed to fix the issue
# ─────────────────────────────────────────────────────────────────────────

def team_router_node(state: AnalysisState) -> dict:
    """Recommend which IT team(s) should handle this incident."""

    print("\n[Team Router] Identifying responsible teams …")

    system = SystemMessage(content=(
        "You are an ITIL Service Desk Manager responsible for assigning incidents "
        "to the correct resolver groups.\n\n"
        "Available teams:\n"
        "  • Service Desk         — first-line triage and user communication\n"
        "  • Database Team        — DB servers, replication, failover\n"
        "  • Platform / Infra     — cloud infra, VMs, storage\n"
        "  • Application Support  — microservices, APIs, deployments\n"
        "  • Network Team         — load balancers, firewalls, DNS\n"
        "  • Security / SIRT      — security incidents, breaches\n"
        "  • Change Advisory Board— required if a change must be approved\n\n"
        "Your output MUST contain:\n"
        "  • Primary Team (owns the incident end-to-end)\n"
        "  • Supporting Teams (if any — with specific tasks)\n"
        "  • Escalation path (who to call if the primary team cannot resolve it)\n"
        "  • Reason for your recommendation\n"
        "  • Communication responsibilities (who updates the business?)\n\n"
        "Be concise — aim for 150-200 words."
    ))

    human = HumanMessage(content=(
        f"## ITIL Incident Summary\n{state['itil_summary']}\n\n"
        f"## Criticality Report\n{state['criticality_report']}"
        f"\n\n## Extra ITIL Context from Local RAG\n{state['rag_context']}"
    ))

    response = team_llm.invoke([system, human])

    print("[Team Router] Done.")

    return {
        "team_recommendation": response.content,
        "messages": [response],
    }


# ─────────────────────────────────────────────────────────────────────────
# NODE 5 — Supervisor (Final Briefing)
#
# The Supervisor reads ALL the specialist reports and writes a single,
# clear, executive-level briefing for the on-call engineer.
#
# This is the key benefit of a multi-agent system:
#   Each agent is a specialist at ONE thing.
#   The Supervisor synthesises their work into one coherent output.
#   The human only has to read one document.
# ─────────────────────────────────────────────────────────────────────────

def supervisor_node(state: AnalysisState) -> dict:
    """Synthesise all agent reports into a final incident briefing."""

    print("\n[Supervisor] Writing final incident briefing …")

    system = SystemMessage(content=(
        "You are the IT Service Management Supervisor on call.\n\n"
        "You have received three specialist reports:\n"
        "  1. ITIL Incident Summary      — what happened in ITIL terms\n"
        "  2. Criticality Assessment     — priority level and business impact\n"
        "  3. Team Assignment            — who should own and work the incident\n\n"
        "Write a concise, professional INCIDENT BRIEFING that an on-call engineer "
        "can read in under 60 seconds and know exactly what to do next.\n\n"
        "Format your briefing with these clearly labelled sections:\n"
        "  ── INCIDENT OVERVIEW ──\n"
        "  ── PRIORITY & IMPACT ──\n"
        "  ── IMMEDIATE ACTIONS ──  (numbered, in order of priority)\n"
        "  ── ASSIGNED TEAMS ──\n"
        "  ── ESCALATION CONTACTS ──\n"
        "  ── COMMUNICATION NOTE ──  (what to tell the business)\n\n"
        "Use plain, direct language.  Avoid jargon not already defined in the reports.\n"
        "Aim for 250-350 words total."
    ))

    human = HumanMessage(content=(
        f"## 0 — RAG Document Sources (JSON)\n{state['rag_doc_list']}\n\n"
        f"## 1 — ITIL Incident Summary\n{state['itil_summary']}\n\n"
        f"## 2 — Criticality Assessment\n{state['criticality_report']}\n\n"
        f"## 3 — Team Assignment\n{state['team_recommendation']}"
    ))

    response = supervisor_llm.invoke([system, human])

    print("[Supervisor] Briefing ready.")

    return {
        "final_briefing": response.content,
        "messages": [response],
    }


# ═══════════════════════════════════════════════════════════════════════════
#  SECTION 7 — BUILD THE LANGGRAPH WORKFLOW
#
#  A LangGraph workflow is a Directed Acyclic Graph (DAG):
#    • Each NODE is a function (one of the agents above)
#    • Each EDGE is a connection saying "after node A, run node B"
#    • set_entry_point() says which node runs first
#    • add_edge(X, END) says X is the last step
#
#  Because the flow is strictly linear here (no branches, no loops),
#  we use add_edge() for every connection — simple and easy to follow.
# ═══════════════════════════════════════════════════════════════════════════

def build_workflow() -> object:
    """Build and compile the multi-agent LangGraph workflow."""

    # Create a new graph whose nodes share AnalysisState
    graph = StateGraph(AnalysisState)

    # ── Register every node ───────────────────────────────────────────────
    # The string names ("data_loader", "itil_translator", …) are what we use
    # in add_edge() calls below to connect the nodes.
    graph.add_node("data_loader",    data_loader_node)    # Loads log + ITIL docs
    graph.add_node("itil_translator", itil_translator_node) # ITIL terminology
    graph.add_node("criticality",    criticality_agent_node) # Severity rating
    graph.add_node("team_router",    team_router_node)    # Team assignment
    graph.add_node("supervisor",     supervisor_node)     # Final briefing

    # ── Set the entry point ───────────────────────────────────────────────
    # The graph always starts here — data must be loaded before any analysis
    graph.set_entry_point("data_loader")

    # ── Connect nodes in a straight pipeline ─────────────────────────────
    # Read as: "after data_loader finishes, run itil_translator"
    graph.add_edge("data_loader",     "itil_translator")
    graph.add_edge("itil_translator", "criticality")
    graph.add_edge("criticality",     "team_router")
    graph.add_edge("team_router",     "supervisor")

    # When the supervisor finishes, the workflow is complete
    graph.add_edge("supervisor", END)

    # compile() validates the graph (checks for missing nodes, broken edges)
    # and returns a runnable object we can call with .invoke()
    return graph.compile()


# ═══════════════════════════════════════════════════════════════════════════
#  SECTION 8 — PRETTY PRINT HELPER
#
#  Just a small helper to make the terminal output readable.
#  Nothing AI-related here — pure formatting.
# ═══════════════════════════════════════════════════════════════════════════

def print_section(title: str, content: str, width: int = 70) -> None:
    """Print a labelled section with a border — makes the output easy to scan."""
    border = "═" * width
    print(f"\n{border}")
    print(f"  {title}")
    print(border)
    # textwrap.fill wraps long lines so the terminal output is readable
    for paragraph in content.strip().split("\n"):
        if paragraph.strip():
            print(textwrap.fill(paragraph.strip(), width=width - 2, subsequent_indent="  "))
        else:
            print()
    print(border)


# ═══════════════════════════════════════════════════════════════════════════
#  SECTION 9 — MAIN ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════════

def main() -> None:
    print("\n" + "═" * 70)
    print("  IT Log Analysis — Multi-Agent ITIL Orchestration Demo")
    print("  Model:", MODEL_NAME)
    print("  Embed:", EMBED_MODEL)
    print("  Log  :", LOG_FILE)
    print("  RAG  :", "rebuild each run" if REBUILD_RAG_EACH_RUN else "reuse existing store")
    print("═" * 70)

    # Step 1: Make sure the log file exists (creates it if necessary)
    create_sample_log()

    # Step 2: Build the LangGraph workflow (connects all agent nodes)
    print("\n[Setup] Building multi-agent workflow …")
    app = build_workflow()
    print("[Setup] Workflow compiled successfully.")

    # Step 3: Define the initial state
    # We only set the 'messages' key here — all other keys start empty ("").
    # Each node will fill in its own key as the workflow progresses.
    initial_state: AnalysisState = {
        "messages": [
            HumanMessage(content=f"Please analyse the log file: {LOG_FILE}")
        ],
        "log_content":          "",
        "itil_context":         "",
        "rag_context":          "",
        "rag_doc_list":         "",
        "itil_summary":         "",
        "criticality_report":   "",
        "team_recommendation":  "",
        "final_briefing":       "",
    }

    # Step 4: Run the full workflow
    # app.invoke() executes every node in order and returns the final state
    print("\n[Run] Starting multi-agent analysis …")
    final_state = app.invoke(initial_state)
    print("[Run] All agents finished.")

    # Step 5: Display results
    # Each specialist's report is stored in a dedicated state key —
    # making it trivial to display, log, or send to a ticketing system.
    print_section("RAW LOG (first 20 lines)", "\n".join(
        final_state["log_content"].splitlines()[:20]
    ))

    print_section("ITIL INCIDENT SUMMARY  (ITIL Translator Agent)",
                  final_state["itil_summary"])

    print_section("CRITICALITY ASSESSMENT  (Criticality Agent)",
                  final_state["criticality_report"])

    print_section("TEAM ASSIGNMENT  (Team Router Agent)",
                  final_state["team_recommendation"])

    print_section("★  FINAL INCIDENT BRIEFING  (Supervisor)  ★",
                  final_state["final_briefing"])

    # Optional: automatically save the briefing to a file next to the log
    briefing_file = LOG_FOLDER / "incident_briefing.txt"
    briefing_file.write_text(
        f"Generated: {datetime.now().isoformat()}\n\n"
        + final_state["final_briefing"],
        encoding="utf-8",
    )
    print(f"\n[Done] Briefing saved → {briefing_file}")


if __name__ == "__main__":
    main()
