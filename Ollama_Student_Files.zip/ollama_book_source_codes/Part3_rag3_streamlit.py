"""
rag_simple2_streamlit.py — Minimal RAG using:
- LangChain for chunking (RecursiveCharacterTextSplitter)
- LangChain for embeddings (OllamaEmbeddings)
- Ollama SDK for final answer generation
- ChromaDB as in-memory vector store
- Streamlit UI for upload + question/answer

Setup (Windows):
- Install:
    pip install ollama streamlit chromadb langchain-ollama langchain-community langchain-text-splitters
- Start Ollama:
    ollama serve
- Pull models (once):
    ollama pull llama3.2
    ollama pull mxbai-embed-large
- Run:
    streamlit run rag_simple2_streamlit.py
"""

import ollama                      # For final LLM answer generation
import chromadb                    # Simple in-memory vector DB
import streamlit as st             # Web UI
from langchain_ollama import OllamaEmbeddings  # LangChain wrapper to call Ollama embeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter  # LangChain chunker

# Choose models
LLM_MODEL = "llama3.2"            # Text-generation model for the final answer
EMBED_MODEL = "mxbai-embed-large" # Embedding model to vectorize chunks and queries

st.title("Minimal RAG with LangChain + Ollama + ChromaDB")

# 1) File uploader: we keep it simple and accept only .txt for beginners
uploaded_file = st.file_uploader("Upload a text file (.txt):", type=["txt"])

# Button to build the index from the uploaded file
if st.button("Index file"):
    if not uploaded_file:
        st.warning("Please upload a .txt file first.")
    else:
        # Read uploaded file as text (UTF-8). Errors ignored for simplicity.
        text = uploaded_file.read().decode("utf-8", errors="ignore")

        # 2) Split the document into small, overlapping chunks
        #    - Smaller chunks improve retrieval
        #    - Overlap keeps continuity between chunks
        splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
        chunks = splitter.split_text(text)

        if not chunks:
            st.error("No text content found in the file.")
        else:
            with st.spinner("Computing embeddings and building vector store..."):
                # 3) Create the LangChain embeddings object (calls your local Ollama server)
                embedder = OllamaEmbeddings(model=EMBED_MODEL)

                # 4) Create an in-memory ChromaDB collection and add chunk vectors
                client = chromadb.Client()  # In-memory store (simplest for demos)
                collection = client.get_or_create_collection("uploaded_doc")

                # Compute embeddings for all chunks (list of float vectors)
                doc_vectors = embedder.embed_documents(chunks)

                # Add to the vector store with simple IDs (one per chunk)
                ids = [f"chunk-{i}" for i in range(len(chunks))]
                collection.add(ids=ids, documents=chunks, embeddings=doc_vectors)

                # Save objects in session_state so we can reuse them for questions
                st.session_state.collection = collection
                st.session_state.embedder = embedder

            st.success(f"Indexed {len(chunks)} chunks. You can now ask questions below.")

# 5) Ask a question about the uploaded document
question = st.text_input("Ask a question about the uploaded document:")

# Button to get the answer from the LLM using retrieved context
if st.button("Get answer"):
    # Basic checks to ensure we have an index and a question
    if "collection" not in st.session_state or "embedder" not in st.session_state:
        st.warning("Please upload and index a file first.")
    elif not question.strip():
        st.warning("Please enter a question.")
    else:
        with st.spinner("Retrieving context and generating answer..."):
            # 6) Embed the user question and retrieve top matching chunks from ChromaDB
            q_vec = st.session_state.embedder.embed_query(question)
            results = st.session_state.collection.query(query_embeddings=[q_vec], n_results=3)
            top_chunks = results["documents"][0]  # top matches for this single query

            # 7) Build a prompt with retrieved context + the question
            #    This is the "RAG" step: ground the LLM with relevant text
            context = "\n\n".join(top_chunks)
            prompt = (
                "Use ONLY the context below to answer the question.\n\n"
                f"Context:\n{context}\n\n"
                f"Question: {question}\n\n"
                "Answer clearly:"
            )

            # 8) Generate final answer with Ollama SDK (local llama3.2)
            try:
                result = ollama.generate(model=LLM_MODEL, prompt=prompt)
                answer = result.get("response", "").strip()
                st.subheader("Answer")
                st.write(answer if answer else "(no response)")
            except Exception as e:
                # Common issues: Ollama server not running or models not pulled
                st.error(f"Error generating answer: {e}")

# Tips for beginners (inline helper text)
st.caption(
    "How it works: Upload text → Split into chunks → Embed with Ollama → Store in Chroma → "
    "Embed your question → Retrieve relevant chunks → Ask LLM with that context."
)