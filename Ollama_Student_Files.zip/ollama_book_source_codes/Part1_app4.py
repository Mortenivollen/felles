import ollama  # Python SDK for interacting with a local Ollama server (localhost:11434)

model = "llama3.2"  # Default model used across repo; ensure it's pulled: `ollama pull llama3.2`

# Sample travel packing items to be categorized by the LLM
items = [
    "Passport",
    "Sunglasses",
    "Toothbrush",
    "Toothpaste",
    "Shampoo",
    "Conditioner",
    "Sunscreen",
    "First Aid Kit",
    "Phone Charger",
    "Power Bank",
    "Headphones",
    "Laptop",
    "Adapter",
    "Camera",
    "Notebook",
    "Pen",
    "Water Bottle",
    "Snacks",
    "Travel Pillow",
    "Blanket",
    "Umbrella",
    "Raincoat",
    "Hiking Boots",
    "Flip Flops",
    "Swimsuit",
    "Towel",
    "Jeans",
    "T-Shirts",
    "Sweater",
    "Jacket",
    "Socks",
    "Underwear",
    "Pajamas",
    "Watch",
    "Wallet",
    "Cash",
    "Credit Cards",
    "Travel Guide",
    "Books",
    "E-Reader",
    "Medications",
    "Hand Sanitizer",
    "Face Mask",
    "Tissues",
    "Sewing Kit",
    "Laundry Bag",
    "Reusable Shopping Bag"
]

# Instruction prompt:
# - Explains the assistant's role
# - Injects the items list (f-string)
# - Asks for categorization and alphabetical sorting within each category
prompt = f"""
You are an assistant that helps users organize items for a travel packing list.

Here is a list of items:
{items}

Please:
1. Categorize these items into groups such as Clothing, Toiletries, Food, Electronics, and Miscellaneous.
2. Sort the items alphabetically within each category.
"""

try:
    # Call Ollama to generate text using the specified model and prompt
    # Returns a dict with keys like 'model', 'created_at', 'response', 'done', etc.
    response = ollama.generate(
        model=model,
        prompt=prompt  # Contains both instructions and the item list
    )

    # Extract only the generated text portion
    generated_text = response.get("response","")

    # Pretty print the result header + model output
    print("Travel Packing List:")
    print(generated_text)

except Exception as e:
    # Handle connectivity/model errors (e.g., Ollama not running) and print message
    print("An error occurred:", str(e))