"""
app5.py — Simple starter: use the Ollama Python SDK and LangChain (ChatOllama).

What this script shows:
- Direct usage of the Ollama Python SDK (ask a prompt, get a response).
- A tiny LangChain pipeline using ChatOllama + a prompt template + output parser.

Prerequisites (Windows):
1) Install packages (in a terminal):
   pip install ollama langchain langchain-community langchain-ollama

2) Start the local Ollama server (in another terminal):
   ollama serve

3) Pull the base model once (only needed the first time):
   ollama pull llama3.2

4) Run this script:
   python app5.py

Notes:
- Default model is "llama3.2" to match this repo.
- To switch models, change MODEL_NAME below and ensure you've pulled it via `ollama pull <name>`.
"""

import sys
import ollama  # Native Python SDK for talking to the local Ollama server at http://localhost:11434

# LangChain pieces:
# - ChatOllama: an LLM wrapper for talking to local Ollama models via LangChain
# - ChatPromptTemplate: structured prompts (system + user roles)
# - StrOutputParser: converts model output to plain text
from langchain_ollama import ChatOllama
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser


# Repo-default model; ensure it's available: `ollama pull llama3.2`
MODEL_NAME = "llama3.2"


def preflight_checks():
    """
    Quick checks to give friendly errors if the server/model isn't ready.
    - Verifies the Ollama server is reachable (ollama.list()).
    - Optionally verifies the model exists locally (ollama.show()).
    """
    try:
        _ = ollama.list()  # If the server is down, this will raise an error.
    except Exception as e:
        print(
            "Could not reach the Ollama server. Make sure it is running with 'ollama serve'.\n"
            f"Details: {e}"
        )
        sys.exit(1)

    try:
        # 'show' returns metadata if the model exists locally.
        _ = ollama.show(MODEL_NAME)
    except Exception:
        print(
            f"Model '{MODEL_NAME}' not found locally. Pull it first:\n"
            f"  ollama pull {MODEL_NAME}"
        )
        sys.exit(1)


def demo_with_ollama_sdk():
    """
    Example 1: Directly use the Ollama SDK to generate text.

    Flow:
    - Provide a plain-text prompt.
    - Call ollama.generate(model=..., prompt=...).
    - Extract the 'response' field from the returned dict.

    Why this is useful:
    - Minimal dependencies and quick to prototype.
    """
    prompt = "In one sentence, explain what a Large Language Model is."
    # The result is a dict with keys like: 'model', 'created_at', 'response', 'done', etc.
    result = ollama.generate(model=MODEL_NAME, prompt=prompt)

    # Safely extract the text portion; .get avoids KeyError if the key is missing.
    text = result.get("response", "").strip()

    print("\n[Ollama SDK] Prompt:", prompt)
    print("[Ollama SDK] Response:", text)


def demo_with_langchain():
    """
    Example 2: Use LangChain's ChatOllama to build a small, composable chain.

    Why LangChain:
    - Lets you define reusable prompt templates (system/user).
    - Composes steps as a pipeline: Prompt -> LLM -> Output Parser.
    - Makes it easy to swap LLMs and add tools/retrievers later.

    Steps:
    1) Create a ChatPromptTemplate with a system instruction and a user message variable {question}.
    2) Initialize ChatOllama(model=..., temperature=...).
    3) Pipe the prompt into the model, then parse the result to a string using StrOutputParser().
    4) Invoke the chain with a value for {question}.
    """
    # Prompt with a short system message (behavior) and a templated user message.
    prompt = ChatPromptTemplate.from_messages(
        [
            # System messages set high-level behavior. Keep it short and specific.
            ("system", "You are a helpful, concise assistant."),
            # The {question} variable is filled in at runtime via chain.invoke({"question": "..."}).
            ("user", "Answer clearly and in bullet points: {question}")
        ]
    )

    # ChatOllama connects LangChain to your local Ollama model.
    # temperature controls randomness (0.0 = deterministic, >0 = more creative).
    llm = ChatOllama(model=MODEL_NAME, temperature=0.2)

    # Convert the model's message output to a plain string.
    parser = StrOutputParser()

    # Create a simple pipeline: PromptTemplate -> LLM -> OutputParser
    chain = prompt | llm | parser

    # Provide content for the {question} placeholder in the prompt.
    user_question = "What are three practical uses of running LLMs locally on a developer laptop?"
    answer = chain.invoke({"question": user_question}).strip()

    print("\n[LangChain] Question:", user_question)
    print("[LangChain] Answer:\n", answer)


def main():
    # Help learners fail fast with clear messages if setup isn't ready.
    preflight_checks()

    # Run both demos so students can compare approaches.
    demo_with_ollama_sdk()
    demo_with_langchain()


if __name__ == "__main__":
    main()