from datetime import datetime

# LangChain message types:
#   HumanMessage  — a message from the user
#   SystemMessage — instructions given to the LLM before the conversation starts
#   ToolMessage   — the result we send back after running a tool
from langchain_core.messages import HumanMessage, SystemMessage, ToolMessage

# @tool turns a regular Python function into a tool the LLM can call by name
from langchain_core.tools import tool

# ChatOllama lets us talk to a locally running Ollama model
from langchain_ollama import ChatOllama


# --- Define the tools the LLM is allowed to use ---

@tool
def get_current_time(_: str = "") -> str:
    """Return current local time."""
    # datetime.now() gives the current date and time
    # strftime formats it as a readable string, e.g. "2026-03-16 14:30:00"
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


@tool
def calculate(expression: str) -> str:
    """Evaluate a simple math expression like 12 * (3 + 4)."""
    # Only allow safe characters to prevent code injection
    allowed = set("0123456789+-*/(). %")
    if not set(expression) <= allowed:
        return "Error: unsupported characters in expression."

    try:
        # eval() computes the math; passing empty dicts blocks access to
        # built-in functions so it can't run arbitrary Python code
        result = eval(expression, {"__builtins__": {}}, {})
        return str(result)
    except Exception as exc:
        return f"Error: {exc}"


# --- Register tools so the LLM knows about them ---

# A list of all tools we want the LLM to be able to use
TOOLS = [get_current_time, calculate]

# A dictionary mapping each tool's name to the function itself.
# We use this later to look up and call the right tool by name.
TOOLS_BY_NAME = {tool_fn.name: tool_fn for tool_fn in TOOLS}


# --- Set up the LLM ---

# Create a chat model that runs locally via Ollama.
# temperature=0 makes responses deterministic (no randomness).
llm = ChatOllama(model="llama3.2", temperature=0)

# bind_tools tells the LLM which tools exist and how to call them.
# The LLM will now include tool call requests in its responses when needed.
llm_with_tools = llm.bind_tools(TOOLS)


# --- System prompt ---

# This text is sent to the LLM before every conversation as background instructions
SYSTEM_TEXT = (
    "You are a practical assistant. "
    "Use tools when needed for time and math. "
    "If no tool is needed, answer directly and briefly."
)


# --- Agent loop ---

def run_agent_turn(messages: list) -> str:
    """Send messages to the LLM and handle any tool calls it makes."""

    # Step 1: Send the conversation history to the LLM and get its response.
    # The response may contain a plain text answer OR a request to call a tool.
    ai_message = llm_with_tools.invoke(messages)

    # Add the LLM's response to the conversation history
    messages.append(ai_message)

    # Step 2: Check whether the LLM wants to call any tools.
    # If tool_calls is empty, the LLM answered directly — we're done.
    if not ai_message.tool_calls:
        return ai_message.content  # Plain text answer, return it immediately

    # Step 3: The LLM requested one or more tools — run each one.
    # tool_calls is a list of dicts like:
    #   {"name": "calculate", "args": {"expression": "2+2"}, "id": "abc123"}
    for call in ai_message.tool_calls:
        # Look up the matching Python function by the tool name
        tool_fn = TOOLS_BY_NAME.get(call["name"])

        if tool_fn:
            # Call the tool with the arguments the LLM provided
            tool_result = tool_fn.invoke(call["args"])
        else:
            tool_result = f"Unknown tool: {call['name']}"

        # Wrap the result in a ToolMessage and add it to the conversation.
        # tool_call_id links this result back to the specific tool request.
        messages.append(ToolMessage(content=str(tool_result), tool_call_id=call["id"]))

    # Step 4: Call the LLM again now that it can see the tool results.
    # It will use those results to compose a final plain-text answer.
    final_message = llm_with_tools.invoke(messages)
    messages.append(final_message)
    return final_message.content


# --- Example questions (non-interactive) ---

def run_example_questions() -> None:
    questions = [
        "What time is it right now?",
        "What is (1250 * 19) / 100? Explain in one short sentence.",
        "What is the capital of Norway?",
    ]

    for question in questions:
        # Start a fresh conversation for each question.
        # SystemMessage always comes first to set the LLM's behaviour.
        messages = [SystemMessage(content=SYSTEM_TEXT), HumanMessage(content=question)]
        answer = run_agent_turn(messages)
        print(f"\nUser: {question}")
        print("Assistant:", answer)


# --- Interactive chat (conversational) ---

def run_interactive_chat() -> None:
    print("\nInteractive mode started. Type 'exit' to stop.")

    # The system message stays at position 0 for the entire conversation
    messages = [SystemMessage(content=SYSTEM_TEXT)]

    while True:
        user_text = input("You: ").strip()
        if user_text.lower() in {"exit", "quit"}:
            print("Goodbye.")
            break

        # Add the user's message and get the assistant's reply
        messages.append(HumanMessage(content=user_text))
        answer = run_agent_turn(messages)
        print("Assistant:", answer)

        # Keep the conversation history from growing too large.
        # We always keep the system message (index 0) plus the last 24 messages.
        if len(messages) > 25:
            messages = [messages[0]] + messages[-24:]


if __name__ == "__main__":
    run_example_questions()
    run_interactive_chat()
