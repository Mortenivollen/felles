"""Generate DOCX files for exercise markdown docs.

Creates DOCX for exercise4.md through exercise8.md in exercises.
"""

import re
from pathlib import Path

from docx import Document


ROOT = Path(__file__).resolve().parent
EX_DIR = ROOT / "exercises"
TARGETS = [
    "exercise4.md",
    "exercise5.md",
    "exercise6.md",
    "exercise7.md",
    "exercise8.md",
]


def markdown_to_docx(md_path: Path, docx_path: Path) -> None:
    doc = Document()

    for raw_line in md_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.rstrip()

        if not line:
            doc.add_paragraph("")
            continue

        if line.startswith("# "):
            doc.add_heading(line[2:].strip(), level=1)
            continue
        if line.startswith("## "):
            doc.add_heading(line[3:].strip(), level=2)
            continue
        if line.startswith("### "):
            doc.add_heading(line[4:].strip(), level=3)
            continue
        if line.startswith("- "):
            doc.add_paragraph(line[2:].strip(), style="List Bullet")
            continue
        if re.match(r"^\d+\.\s+", line):
            text = re.sub(r"^\d+\.\s+", "", line)
            doc.add_paragraph(text.strip(), style="List Number")
            continue

        doc.add_paragraph(line)

    doc.save(docx_path)


def main() -> int:
    for name in TARGETS:
        md_path = EX_DIR / name
        docx_path = EX_DIR / name.replace(".md", ".docx")
        if not md_path.exists():
            print(f"Skipping missing file: {md_path}")
            continue

        markdown_to_docx(md_path, docx_path)
        print(f"Generated: {docx_path}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
