# Course Workspace Overview

Dette repoet inneholder et komplett 3-dagers kursløp for Ollama, LangChain, RAG, agenter, LangGraph og MCP.

## Start Here

1. [course_docs/workspace_oversikt.md](course_docs/workspace_oversikt.md) — tydelig mappe- og filoversikt
2. [course_docs/undervisningsplan_detaljert.md](course_docs/undervisningsplan_detaljert.md) — detaljert undervisningsplan
3. [exercises/README.md](exercises/README.md) — alle øvelser med startere, løsninger og DOCX
4. [MAPPEGUIDE.md](MAPPEGUIDE.md) — superkort "hvor finner jeg hva"

## Folder Guide

| Folder | Hva den inneholder |
|---|---|
| course_docs/ | guider, planverk, oversikter |
| exercises/ | øvelser 1-8 i md/docx + mapping + micro-oppgaver |
| startscripts/ | startmaler for øvelser 4-8 |
| solutions/ | løsningsforslag for øvelser 1-8 |
| logs/ | logger og genererte briefinger |
| itil_docs/ | nedlastede ITIL-tekster til RAG |
| rag_store/ | lokal Chroma persistens |

## Structure Snapshot

```text
.
|-- course_docs/
|-- exercises/
|-- startscripts/
|-- solutions/
|-- logs/
|-- itil_docs/
|-- rag_store/
|-- start_exercises.py
|-- generate_exercise_docx.py
|-- generate_course_docs_docx.py
```

## Course Documents

- [course_docs/workspace_oversikt.md](course_docs/workspace_oversikt.md)
- [course_docs/workspace_oversikt.docx](course_docs/workspace_oversikt.docx)
- [course_docs/undervisningsplan_detaljert.md](course_docs/undervisningsplan_detaljert.md)
- [course_docs/undervisningsplan_detaljert.docx](course_docs/undervisningsplan_detaljert.docx)
- [course_docs/undervisningsplan_2_dager_komprimert.md](course_docs/undervisningsplan_2_dager_komprimert.md)
- [course_docs/undervisningsplan_2_dager_komprimert.docx](course_docs/undervisningsplan_2_dager_komprimert.docx)
- [course_docs/instruktornotater_timeblokker.md](course_docs/instruktornotater_timeblokker.md)
- [course_docs/instruktornotater_timeblokker.docx](course_docs/instruktornotater_timeblokker.docx)
- [course_docs/deltakerhandout.md](course_docs/deltakerhandout.md)
- [course_docs/deltakerhandout.docx](course_docs/deltakerhandout.docx)
- [course_docs/kursleder_cheat_sheet.md](course_docs/kursleder_cheat_sheet.md)
- [course_docs/kursleder_cheat_sheet.docx](course_docs/kursleder_cheat_sheet.docx)

## Exercise Documents

- [exercises/exercise1.md](exercises/exercise1.md)
- [exercises/exercise2.md](exercises/exercise2.md)
- [exercises/exercise3.md](exercises/exercise3.md)
- [exercises/exercise4.md](exercises/exercise4.md)
- [exercises/exercise5.md](exercises/exercise5.md)
- [exercises/exercise6.md](exercises/exercise6.md)
- [exercises/exercise7.md](exercises/exercise7.md)
- [exercises/exercise8.md](exercises/exercise8.md)

## Planning and Progression

- [exercises/script_mapping.md](exercises/script_mapping.md) — kobling mellom scripts og øvelser
- [exercises/micro_exercises.md](exercises/micro_exercises.md) — 15-20 min mini-oppgaver

## Utility Scripts

- start_exercises.py — meny for kjøring av startskript og løsninger
- generate_exercise_docx.py — genererer DOCX for exercise4-8
- generate_course_docs_docx.py — genererer DOCX for kursoversikt og undervisningsplan

## Quick Start

```powershell
python -m pip install -r requirements.txt
python start_exercises.py
```
