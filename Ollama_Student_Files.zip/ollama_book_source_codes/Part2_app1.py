"""
app5.py — Smallest possible demo of LangChain with a local Ollama model.

Setup (Windows):
1) Install:
   pip install langchain langchain-community langchain-ollama
2) Start Ollama server:
   ollama serve
3) Pull a model (once):
   ollama pull llama3.2
4) Run:
   python app5.py
"""

# LangChain components:
# - ChatOllama: talks to your local Ollama model
# - ChatPromptTemplate: builds a simple system+user prompt
# - StrOutputParser: returns a plain string
from langchain_ollama import ChatOllama
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

MODEL_NAME = "llama3.2"  # Default model in this repo

# 1) Create a tiny prompt template (system behavior + a single user variable {question})
prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful, concise assistant."),
    ("user", "{question}")
])

# 2) Initialize the local chat model (temperature controls creativity; lower = more deterministic)
llm = ChatOllama(model=MODEL_NAME, temperature=0.2)

# 3) Parse model output to a plain string
#    What the parser does:
#    - ChatOllama returns a structured AIMessage (e.g., with role/content).
#    - StrOutputParser() extracts just the text content so beginners can print/use a plain string.
#    - If you skipped this, you'd need to access message.content yourself.
parser = StrOutputParser()

# 4) Build a simple chain: Prompt -> LLM -> Parser
#    What "chain" means here:
#    - The | operator composes steps into a pipeline (called Runnables in LangChain).
#      a) prompt: formats the template by filling {question} into system/user messages.
#      b) llm: sends the formatted messages to the local model and returns an AIMessage.
#      c) parser: converts that AIMessage to a plain string.
#    - You can call chain.invoke(...) with the variables needed by the prompt (here: {"question": "..."}).
chain = prompt | llm | parser

# 5) Provide a question and run the chain
#    .invoke runs synchronously and returns the final string from the parser.
question = "Give three benefits of running LLMs locally."
answer = chain.invoke({"question": question}).strip()

# 6) Print result
print("Q:", question)
print("A:", answer)