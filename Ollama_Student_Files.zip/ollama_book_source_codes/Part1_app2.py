import ollama

res = ollama.chat(
    model="llama3.2",
    messages=[
        {"role": "user", "content": "why are trees green?"}
    ],

)

 
#print(ollama.show("llama3.2"))
#print(res)

# Extract and print assistant message content safely
message = res.get("message")
print(message)

