import asyncio
import os

from langchain_ollama import ChatOllama
from langchain_mcp_adapters.client import MultiServerMCPClient
from langgraph.prebuilt import create_react_agent


MODEL_NAME = "llama3.2:3b"
REMOTE_MCP_URL = os.getenv("REMOTE_MCP_URL", "https://learn.microsoft.com/api/mcp")


async def run_agent_demo() -> None:
    """Run a LangGraph agent that uses remote MCP tools and an Ollama model."""

    client = MultiServerMCPClient(
        {
            "remote_demo": {
                "url": REMOTE_MCP_URL,
                "transport": "streamable_http",
            }
        }
    )

    tools = await client.get_tools()

    llm = ChatOllama(model=MODEL_NAME, temperature=0)

    query = (
        "What course day is this demo for, and what is 12 * 7? "
        "Use tools when useful and answer briefly."
    )

    result = await create_react_agent(llm, tools).ainvoke(
        {
            "messages": [
                {
                    "role": "system",
                    "content": "You are a practical assistant. Use MCP tools when needed.",
                },
                {"role": "user", "content": query},
            ]
        }
    )

    final_message = result["messages"][-1]
    final_text = getattr(final_message, "content", str(final_message))

    print("Remote MCP URL:", REMOTE_MCP_URL)
    print("User:", query)
    print("Assistant:", final_text)


if __name__ == "__main__":
    asyncio.run(run_agent_demo())
