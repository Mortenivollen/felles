"""
Minimal RAG with ChromaDB + Ollama SDK using mxbai-embed-large.

Setup (Windows):
- Install: pip install ollama chromadb
- Start Ollama: ollama serve
- Pull models (once): 
    ollama pull llama3.2
    ollama pull mxbai-embed-large
- Place constitution.txt next to this script
- Run: python rag_simple.py
"""

import os
import ollama            # Ollama SDK: call local models for embeddings and generation
import chromadb          # ChromaDB: simple in-memory vector store

# Choose a text-generation model and an embedding model
LLM_MODEL = "llama3.2"
EMBED_MODEL = "mxbai-embed-large"
DOC_PATH = "constitution.txt"  # Document we index for RAG


def chunk_text(text: str, chunk_size: int = 1000, overlap: int = 200):
    """
    Split long text into smaller chunks with a bit of overlap.
    - chunk_size: max characters per chunk
    - overlap: shared chars between consecutive chunks (keeps context continuity)
    """
    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        chunks.append(text[start:end])
        start += max(chunk_size - overlap, 1)  # move forward with overlap
    return chunks


def embed_text(text: str):
    """
    Turn text into a numeric vector using Ollama's embedding model.
    - We pass the text via 'prompt' and read the 'embedding' from the result.
    """
    return ollama.embeddings(model=EMBED_MODEL, prompt=text)["embedding"]  # take the vector field from Ollama's response


def main():
    # 1) Load the source document
    if not os.path.exists(DOC_PATH):
        print(f"Missing file: {DOC_PATH}")
        return
    full_text = open(DOC_PATH, "r", encoding="utf-8").read()

    # 2) Chunk the document (small pieces are easier to retrieve)
    chunks = chunk_text(full_text)

    # 3) Create a ChromaDB collection and add chunks with their embeddings
    client = chromadb.Client()                              # in-memory DB (simple for demos)
    collection = client.get_or_create_collection("constitution")
    ids = [f"chunk-{i}" for i in range(len(chunks))]        # simple IDs
    embeddings = [embed_text(c) for c in chunks]            # vectorize chunks
    collection.add(ids=ids, documents=chunks, embeddings=embeddings)

    # 4) Ask the user a question about the document
    question = input("\nAsk a question about the Constitution: ").strip()
    if not question:
        print("No question entered.")
        return

    # 5) Embed the question and retrieve the most relevant chunks
    q_vec = embed_text(question)                            # vector for the query
    results = collection.query(query_embeddings=[q_vec], n_results=3)
    top_chunks = results["documents"][0]                    # top chunks for this single query

    # 6) Build a prompt: put the retrieved chunks as context + the user's question
    context = "\n\n".join(top_chunks)
    prompt = (
        "Use ONLY the context below to answer the question.\n\n"
        f"Context:\n{context}\n\n"
        f"Question: {question}\n\n"
        "Answer clearly:"
    )

    # 7) Generate the final answer with the LLM
    answer = ollama.generate(model=LLM_MODEL, prompt=prompt)["response"].strip()

    # 8) Show the answer
    print("\nAnswer:\n")
    print(answer)


if __name__ == "__main__":
    main()