# LangChain + Ollama Agents With Tools: Practical Beginner Guide

This guide shows a simple, practical way to build a local agent that can use tools with LangChain and Ollama.

You will learn how to:
- Create tools in Python
- Let an Ollama model decide when to call tools
- Run a small agent loop
- Keep conversation history
- Avoid common beginner mistakes

## 1. What is a tool-using agent?

A tool-using agent is an LLM that can:
1. Read your question
2. Decide it needs a tool
3. Call the tool with arguments
4. Use the tool result to produce a better final answer

Example:
- User asks: "What is 19% of 1250 and explain quickly"
- Agent calls a calculator tool
- Agent returns both the number and explanation

## 2. Prerequisites

1. Install Ollama and ensure it is running
   - Windows/macOS: start the Ollama app
   - Linux: run `ollama serve`
2. Pull a model
   - `ollama pull llama3.2:3b`
3. Install packages
   - `pip install langchain langchain-core langchain-ollama`

If you use this repository dependencies:
- `pip install -r requirements.txt`

## 3. Create simple tools

Save as `agent_with_tools.py`:

```python
from datetime import datetime
from langchain_core.tools import tool


@tool
def get_current_time(_: str = "") -> str:
    """Return the current local time."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


@tool
def calculate(expression: str) -> str:
    """Evaluate a simple math expression like '12 * (3 + 4)'."""
    # Beginner-safe example: keep this strict for demos
    allowed = set("0123456789+-*/(). %")
    if not set(expression) <= allowed:
        return "Error: expression contains unsupported characters."

    try:
        result = eval(expression, {"__builtins__": {}}, {})
        return str(result)
    except Exception as exc:
        return f"Error: {exc}"
```

## 4. Bind tools to Ollama model

```python
from langchain_ollama import ChatOllama

model = ChatOllama(model="llama3.2:3b", temperature=0)

tools = [get_current_time, calculate]
llm_with_tools = model.bind_tools(tools)
```

`bind_tools(...)` lets the model return tool calls when needed.

## 5. Minimal agent loop (practical and simple)

This loop:
1. Sends messages to the model
2. Executes requested tools
3. Feeds tool results back
4. Stops when model returns normal text

```python
from langchain_core.messages import HumanMessage, SystemMessage, ToolMessage


def run_agent(user_input: str, max_steps: int = 4) -> str:
    tools_by_name = {t.name: t for t in tools}

    messages = [
        SystemMessage(
            content=(
                "You are a helpful assistant. "
                "Use tools when needed for time or math. "
                "If no tool is needed, answer directly."
            )
        ),
        HumanMessage(content=user_input),
    ]

    for _ in range(max_steps):
        ai_msg = llm_with_tools.invoke(messages)
        messages.append(ai_msg)

        tool_calls = getattr(ai_msg, "tool_calls", None) or []
        if not tool_calls:
            return ai_msg.content

        for call in tool_calls:
            name = call.get("name")
            args = call.get("args", {})
            tool_call_id = call.get("id")

            tool_fn = tools_by_name.get(name)
            if tool_fn is None:
                tool_result = f"Unknown tool: {name}"
            else:
                try:
                    tool_result = tool_fn.invoke(args)
                except Exception as exc:
                    tool_result = f"Tool error from {name}: {exc}"

            messages.append(
                ToolMessage(content=str(tool_result), tool_call_id=tool_call_id)
            )

    return "Stopped: max steps reached before final response."
```

## 6. Run the agent

Add this at the bottom of `agent_with_tools.py`:

```python
if __name__ == "__main__":
    questions = [
        "What time is it?",
        "What is (1250 * 19) / 100? Also explain the result in one sentence.",
        "What is the capital of Norway?",
    ]

    for q in questions:
        print(f"\nUser: {q}")
        print("Assistant:", run_agent(q))
```

Run:
- `python agent_with_tools.py`

## 7. Keep conversation history between turns

If you want a chat-like agent, keep one message list and append each new user turn.

```python
from langchain_core.messages import HumanMessage

chat_history = [
    SystemMessage(content="You are a practical assistant that can use tools.")
]


def run_chat_turn(user_input: str) -> str:
    chat_history.append(HumanMessage(content=user_input))

    # Reuse the same loop idea, but with persistent chat_history
    for _ in range(4):
        ai_msg = llm_with_tools.invoke(chat_history)
        chat_history.append(ai_msg)

        tool_calls = getattr(ai_msg, "tool_calls", None) or []
        if not tool_calls:
            return ai_msg.content

        for call in tool_calls:
            name = call.get("name")
            args = call.get("args", {})
            tool_call_id = call.get("id")
            tool_result = {t.name: t for t in tools}[name].invoke(args)
            chat_history.append(
                ToolMessage(content=str(tool_result), tool_call_id=tool_call_id)
            )

    return "Stopped: max steps reached."
```

Tip:
- Keep only the latest messages (for example last 20) to control token usage.

## 8. Common beginner issues

1. No tool calls happen
   - Fix: make system instruction explicit, for example "Use tools for math/time"

2. Wrong model name
   - Fix: verify with `ollama list` and pull exact model name

3. Tool argument errors
   - Fix: keep tool function signatures simple and validate inputs

4. Agent loops forever
   - Fix: always set `max_steps`

## 9. Practical next steps

1. Add one real tool, for example reading a local JSON file
2. Save chat history to a file so memory survives restarts
3. Add a small command-line menu for repeated questions
4. Reuse this pattern inside your RAG app for hybrid agent + retrieval

## 10. Quick reference

- Model class: `ChatOllama`
- Tool decorator: `@tool`
- Bind tools: `model.bind_tools([...])`
- Tool call messages: `ToolMessage(...)`
- Main pattern: model step -> tool step -> model step
