# Kursleder Cheat Sheet

Kort sjekkliste for gjennomforing av kurset.

## For Dag 1
1. Bekreft at alle har aktivt miljo og tilgang til modeller.
2. Kjor en kort test av lokal modellrespons.
3. Vis hvor filer ligger: course_docs, exercises, startscripts, solutions.

## Under Dag 1
1. Hold teori kort, prioriter hands-on tidlig.
2. Hjelp deltakerne med Exercise 1, 2 og 4.
3. Stopp hver 45-60 min for mini-oppsummering.

## Etter Dag 1
1. Sjekk at alle har minst ett kjorbart script.
2. Del forslag til forbedringer for dag 2.

## For Dag 2
1. Verifiser RAG-forutsetninger (embedding-modell, inputfil).
2. Repetisjon av state, prompt og feilhåndtering.

## Under Dag 2
1. Kjor Exercise 3, 5 og 6 i tydelig progresjon.
2. Be deltakerne forklare retrieval-resultater med egne ord.
3. Logg vanlige feil som oppstår i plenum.

## Etter Dag 2
1. Avklar hvem som trenger ekstra støtte på agentflyt.
2. Forbered enkel mal for dag 3 capstone.

## For Dag 3
1. Klargjor demo for multi-agent og MCP.
2. Definer tydelige krav til gruppeleveranse.

## Under Dag 3
1. Kjor Exercise 7 og 8.
2. Bruk itil_log_agent.py som capstone-referanse.
3. Hold korte statusstopp hvert 30-40 min.

## Etter Dag 3
1. Gjennomfor gruppedemoer med fast tidsramme.
2. Oppsummer hva som kan tas rett inn i egne prosjekter.
3. Del neste steg: gjenbruk av startscripts og solutions.

## Beredskap (hurtig)
1. Hvis modell ikke svarer: restart Ollama og test med minimal prompt.
2. Hvis embedding feiler: sjekk modellnavn og nettverk.
3. Hvis tidspress: bruk komprimert 2-dagers plan og prioriter core-ovelser.
