# LangChain + Ollama in Python: Practical Beginner Guide

This guide shows beginners how to use LangChain together with Ollama in practical Python code.

You will learn how to:
- Connect LangChain to a local Ollama model
- Build your first prompt pipeline
- Stream model output
- Keep chat conversation context
- Create structured JSON output
- Build a minimal local RAG flow

## 1. What is LangChain + Ollama?

- Ollama runs local language models on your machine.
- LangChain helps you build reusable LLM pipelines (prompt -> model -> parser).

Together, they make it easier to build chat apps, automation, and RAG systems with local models.

## 2. Prerequisites

1. Install Ollama from https://ollama.com/download
2. Ensure Ollama is running:
   - Windows/macOS: usually starts with the app
   - Linux: run `ollama serve`
3. Pull a model:
   - `ollama pull llama3.2:3b`
4. Install dependencies:
   - `pip install -r requirements.txt`

If you only want minimum packages:
- `pip install langchain-core langchain-ollama langchain-community chromadb`

## 3. First LangChain call with Ollama

Save as `lc_hello.py`:

```python
from langchain_ollama import ChatOllama

model = ChatOllama(model="llama3.2:3b", temperature=0)

response = model.invoke("Explain what LangChain does in 2 short sentences.")
print(response.content)
```

Run:
- `python lc_hello.py`

## 4. Prompt templates + LCEL pipeline

LangChain Expression Language (LCEL) lets you compose steps with `|`.

```python
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_ollama import ChatOllama

prompt = ChatPromptTemplate.from_template(
    "You are a helpful tutor. Answer clearly for beginners.\nQuestion: {question}"
)

model = ChatOllama(model="llama3.2:3b", temperature=0.2)
parser = StrOutputParser()

chain = prompt | model | parser

result = chain.invoke({"question": "What is the difference between an API and an SDK?"})
print(result)
```

## 5. Streaming output

Use `.stream(...)` to print content gradually.

```python
from langchain_ollama import ChatOllama

model = ChatOllama(model="llama3.2:3b", temperature=0)

for chunk in model.stream("Write a short motivational quote about learning Python."):
    print(chunk.content, end="", flush=True)

print()
```

## 6. Keep conversation history in LangChain

A simple beginner pattern is to keep a list of chat messages and pass it to the model.

```python
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
from langchain_ollama import ChatOllama

model = ChatOllama(model="llama3.2:3b", temperature=0)

messages = [
    SystemMessage(content="You are a friendly coding tutor."),
    HumanMessage(content="What is a Python list?"),
]

first = model.invoke(messages)
print("Assistant:", first.content)

messages.append(AIMessage(content=first.content))
messages.append(HumanMessage(content="Give one short example."))

second = model.invoke(messages)
print("Assistant:", second.content)
```

Tip:
- For long chats, keep only recent messages (for example last 20) to reduce token usage.

## 7. Structured JSON output

You can ask for JSON and parse it into Python data.

```python
import json
from langchain_core.prompts import ChatPromptTemplate
from langchain_ollama import ChatOllama

prompt = ChatPromptTemplate.from_template(
    """
Return only JSON with fields: category, urgency, short_reason.
User request: {text}
"""
)

model = ChatOllama(model="llama3.2:3b", temperature=0, format="json")
chain = prompt | model

raw = chain.invoke({"text": "Production API is down and customers cannot log in."})

data = json.loads(raw.content)
print(data)
```

## 8. Minimal local RAG with Ollama embeddings

This example creates a tiny vector store from local text and asks grounded questions.

```python
from langchain_community.vectorstores import Chroma
from langchain_core.documents import Document
from langchain_core.prompts import ChatPromptTemplate
from langchain_ollama import ChatOllama, OllamaEmbeddings

# 1) Local knowledge base
texts = [
    "Ollama runs LLMs locally.",
    "LangChain helps compose prompt and model pipelines.",
    "RAG retrieves relevant context before generation.",
]

docs = [Document(page_content=t) for t in texts]

# 2) Embeddings + vector store
embeddings = OllamaEmbeddings(model="nomic-embed-text")
vectorstore = Chroma.from_documents(documents=docs, embedding=embeddings)
retriever = vectorstore.as_retriever(search_kwargs={"k": 2})

# 3) Ask question with retrieved context
question = "Why would I use RAG with local models?"
retrieved_docs = retriever.invoke(question)
context = "\n".join(d.page_content for d in retrieved_docs)

prompt = ChatPromptTemplate.from_template(
    """
Answer based only on this context:
{context}

Question: {question}
"""
)

model = ChatOllama(model="llama3.2:3b", temperature=0)
chain = prompt | model

answer = chain.invoke({"context": context, "question": question})
print(answer.content)
```

Notes:
- Pull embedding model first if needed: `ollama pull nomic-embed-text`
- For larger projects, split long files into chunks before indexing.

## 9. Common beginner issues

1. Cannot connect to Ollama
   - Fix: Start Ollama app or run `ollama serve`

2. Model name errors
   - Fix: Pull the exact model name with `ollama pull ...`

3. Slow generation
   - Fix: Use a smaller model (for example `llama3.2:1b`)

4. JSON parse errors
   - Fix: Use `format="json"` and validate with `json.loads(...)` inside `try/except`

## 10. Practical next steps

1. Turn section 4 into a reusable function for your app
2. Add streaming to improve CLI user experience
3. Add a small history store (file or database)
4. Connect section 8 to your own course documents

## 11. Quick reference

- LangChain model class: `ChatOllama`
- Embeddings class: `OllamaEmbeddings`
- Basic single call: `model.invoke(...)`
- Pipeline composition: `prompt | model | parser`
- Streaming: `model.stream(...)`
- JSON mode: `ChatOllama(..., format="json")`
