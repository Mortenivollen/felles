# LangGraph + Ollama Agents in Python: Practical Beginner Guide

This guide shows a simple way to build an agent with LangGraph and Ollama.

You will learn how to:
- Define simple tools
- Create a LangGraph state
- Route between model and tools
- Run a practical agent loop
- Keep conversation context

## 1. What is LangGraph?

LangGraph is a framework for building agent workflows as graphs.

Think of it as:
- Nodes = steps (model call, tool execution, final answer)
- Edges = flow between steps
- State = shared data (for example chat messages)

With Ollama, you can run this locally.

## 2. Prerequisites

1. Install Ollama and run it
   - Windows/macOS: start the Ollama app
   - Linux: `ollama serve`
2. Pull a model
   - `ollama pull llama3.2:3b`
3. Install packages
   - `pip install langgraph langchain-core langchain-ollama`

Optional for this repository:
- `pip install -r requirements.txt`

## 3. Full beginner example (copy and run)

Save as `langgraph_ollama_agent.py`:

```python
from datetime import datetime
from typing import Annotated, TypedDict

from langchain_core.messages import AnyMessage
from langchain_core.tools import tool
from langchain_ollama import ChatOllama
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode


# -------- 1) Define tools --------
@tool
def get_current_time(_: str = "") -> str:
    """Return the current local time."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


@tool
def calculate(expression: str) -> str:
    """Evaluate a simple math expression like '12 * (3 + 4)'."""
    allowed = set("0123456789+-*/(). %")
    if not set(expression) <= allowed:
        return "Error: unsupported characters in expression."

    try:
        result = eval(expression, {"__builtins__": {}}, {})
        return str(result)
    except Exception as exc:
        return f"Error: {exc}"


TOOLS = [get_current_time, calculate]


# -------- 2) Define graph state --------
class AgentState(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]


# -------- 3) Build model and bind tools --------
llm = ChatOllama(model="llama3.2:3b", temperature=0)
llm_with_tools = llm.bind_tools(TOOLS)


# -------- 4) Create graph nodes --------
def call_model(state: AgentState) -> AgentState:
    response = llm_with_tools.invoke(state["messages"])
    return {"messages": [response]}


def route_after_model(state: AgentState) -> str:
    last_message = state["messages"][-1]
    tool_calls = getattr(last_message, "tool_calls", None) or []
    if tool_calls:
        return "tools"
    return "end"


tool_node = ToolNode(TOOLS)

workflow = StateGraph(AgentState)
workflow.add_node("model", call_model)
workflow.add_node("tools", tool_node)

workflow.set_entry_point("model")
workflow.add_conditional_edges(
    "model",
    route_after_model,
    {
        "tools": "tools",
        "end": END,
    },
)
workflow.add_edge("tools", "model")

app = workflow.compile()


# -------- 5) Run a few practical queries --------
if __name__ == "__main__":
    questions = [
        "What time is it?",
        "What is (1250 * 19) / 100? Explain in one sentence.",
        "What is the capital of Norway?",
    ]

    system = (
        "You are a practical assistant. "
        "Use tools when needed for time and math. "
        "If no tool is needed, answer directly."
    )

    for q in questions:
        print(f"\nUser: {q}")
        result = app.invoke(
            {
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": q},
                ]
            }
        )
        final = result["messages"][-1]
        print("Assistant:", final.content)
```

Run:
- `python langgraph_ollama_agent.py`

## 4. Keep conversation history between turns

To make this chat-like, keep one `messages` list and reuse it for each user turn.

```python
conversation = [
    {"role": "system", "content": "You are a practical assistant that can use tools."}
]

while True:
    user_text = input("You: ").strip()
    if user_text.lower() in {"quit", "exit"}:
        break

    conversation.append({"role": "user", "content": user_text})
    result = app.invoke({"messages": conversation})

    assistant_text = result["messages"][-1].content
    print("Assistant:", assistant_text)

    conversation.append({"role": "assistant", "content": assistant_text})
```

Tip:
- Keep only recent messages (for example the last 20) to reduce token usage.

## 5. Common beginner issues

1. `ModuleNotFoundError: langgraph`
   - Fix: `pip install langgraph`

2. No tool usage
   - Fix: add clear system instruction like "Use tools for math and time"

3. Agent repeats too many steps
   - Fix: keep tools focused and ensure your route function exits when there are no tool calls

4. Ollama connection errors
   - Fix: start Ollama app or run `ollama serve`

## 6. Why LangGraph is useful

- You can see and control the agent flow clearly
- It is easier to extend with extra nodes (retrieval, validation, human approval)
- You keep local inference with Ollama

## 7. Practical next steps

1. Add a file-reading tool for your local docs
2. Add a retrieval node before model call
3. Save conversation to JSON so memory survives script restarts
4. Add simple logging for each graph step

## 8. Quick reference

- State type: `TypedDict`
- Message accumulator: `add_messages`
- Tool node: `ToolNode([...])`
- Graph builder: `StateGraph(...)`
- Entry point: `set_entry_point(...)`
- Conditional routing: `add_conditional_edges(...)`
- Run graph: `app.invoke({...})`
