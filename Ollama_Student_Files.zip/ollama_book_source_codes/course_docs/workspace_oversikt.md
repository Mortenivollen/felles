# Workspace Oversikt

Denne oversikten forklarer hva hver mappe og nøkkelfil brukes til.

## Rotnivå

| Sti | Innhold | Når du bruker den |
|---|---|---|
| README.md | Hovedinngang til kursmateriell | Start her for navigasjon |
| requirements.txt | Python-avhengigheter | Før kursstart eller miljøoppsett |
| Part1_app1.py - Part1_app4.py | Grunnleggende Ollama-eksempler | Dag 1 introduksjon |
| Part2_app1.py - Part2_app3.py | LangChain grunnlag + enkel UI | Dag 1 ettermiddag / Dag 2 |
| part3_rag1.py, Part3_rag2.py, Part3_rag3_streamlit.py | RAG-arbeidsflyt (CLI + Streamlit) | Dag 2 |
| Part4_langchain_agent_tools.py, Part4_langgraph_agent.py | Agenter med verktøy og LangGraph | Dag 2 ettermiddag |
| Part5_multi_agent.py, Part5_mcp_ollama_langchain_langgraph.py | Multi-agent og MCP-integrasjon | Dag 3 |
| itil_log_agent.py | Kapteinseksempel: multi-agent + RAG + ITIL-case | Dag 3 capstone |
| gpu_verify.py | Verifisering av GPU/Ollama-kjøring | Før praktiske økter |
| categorizer.py | Enkel prompt-basert kategorisering | Tidlig nybegynnerdemo |
| constitution.txt | Dokument for RAG-øvelser | Øvelse 3 og RAG-demoer |

## Mapper

| Mappe | Innhold | Formål |
|---|---|---|
| course_docs/ | Praktiske guider og kursdokumentasjon | Teori, forklaringer, planverk |
| exercises/ | Oppgaver, DOCX, mapping, micro-oppgaver | Studentoppgaver og progresjon |
| solutions/ | Fasitkode for øvelser | Instruktørstøtte og etterarbeid |
| startscripts/ | Startmaler for øvelser 4-8 | Studentenes kodeutgangspunkt |
| logs/ | Eksempel-logger og genererte briefinger | ITIL-/logganalyse-demo |
| itil_docs/ | Nedlastede ITIL-tekster for RAG | Lokal kunnskapsbase |
| rag_store/ | Persistente vektorindekser (Chroma) | Gjenbruk av embeddings |
| .venv/ | Lokalt Python-miljø | Isolert kjøring av kurset |

## Tydelig struktur (kort)

```text
ollama_book_source_codes/
|-- course_docs/         # planverk og guider
|-- exercises/           # alle øvelsesfiler (md/docx)
|-- startscripts/        # student-startfiler
|-- solutions/           # fasit
|-- logs/                # loggutdata
|-- itil_docs/           # lokale ITIL-kilder
|-- rag_store/           # vektordatabase
```

## Dokumentflyt for undervisning

1. Start i README.md
2. Les oversiktene i course_docs/
3. Kjør øvelser via start_exercises.py
4. Bruk startscripts/ i undervisning
5. Sammenlign med solutions/

## Viktige støtteskript

| Fil | Beskrivelse |
|---|---|
| start_exercises.py | Menybasert starter for øvelser og løsningsforslag |
| generate_exercise_docx.py | Genererer DOCX for exercise4-8 |

## Anbefalt vedlikehold

1. Hold øvelsesnummer og filnavn synkronisert i exercises/README.md.
2. Oppdater script_mapping.md når nye Part-filer legges til.
3. Generer DOCX på nytt etter større tekstendringer i markdown.
