# Deltakerhandout

Velkommen til kurset. Her er alt du trenger, uten tekniske detaljer.

## Hva du lærer
1. Hvordan du kan bruke lokal AI i praksis.
2. Hvordan du stiller gode spørsmål og får bedre svar.
3. Hvordan du bruker dokumenter som kunnskapsgrunnlag.
4. Hvordan en AI-assistent kan bruke verktøy.
5. Hvordan flere AI-roller kan samarbeide.

## Hvordan dagen fungerer
- Korte forklaringer.
- Praktiske oppgaver i små steg.
- Felles demoer underveis.
- Gruppeoppgave mot slutten.

## Hva du skal levere
1. En enkel løsning som svarer på spørsmål fra tekstgrunnlag.
2. En enkel løsning som bruker minst ett verktøy.
3. En kort presentasjon av hva dere bygde.

## Tips for å lykkes
1. Start enkelt, forbedre steg for steg.
2. Les oppgaven nøye før du koder.
3. Test ofte underveis.
4. Spør om hjelp tidlig hvis du står fast.
5. Samarbeid aktivt i gruppen.

## Etter kurset
- Du har et komplett sett med eksempler og øvelser.
- Du kan bygge videre på samme struktur i egne prosjekter.
- Du kan bruke oppgavene som mal i teamet ditt.

Lykke til!
