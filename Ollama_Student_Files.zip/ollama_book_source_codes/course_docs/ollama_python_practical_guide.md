# Ollama in Python: Practical Beginner Guide

This guide gives you a hands-on introduction to using Ollama from Python.

You will learn how to:
- Install and start Ollama
- Pull a model
- Send your first prompt from Python
- Stream responses token-by-token
- Keep conversation history between turns
- Let an agent use conversation history as context
- Ask for structured JSON output
- Handle common beginner errors

## 1. What is Ollama?

Ollama lets you run LLMs locally on your own machine.

In Python, the `ollama` package talks to the local Ollama server (default: `http://localhost:11434`).

## 2. Prerequisites

1. Install Ollama from https://ollama.com/download
2. Start Ollama:
   - On Windows/macOS, the app usually starts a local server automatically
   - On Linux, run: `ollama serve`
3. Pull a model (example):
   - `ollama pull llama3.2:3b`
4. Install Python package:
   - `pip install ollama`

If you are in this repository, you can install all dependencies with:
- `pip install -r requirements.txt`

## 3. Your first Python example

Save as `hello_ollama.py`:

```python
from ollama import chat

response = chat(
    model="llama3.2:3b",
    messages=[
        {"role": "user", "content": "Explain what an API is in 2 simple sentences."}
    ],
)

print(response["message"]["content"])
```

Run:
- `python hello_ollama.py`

## 4. Multi-turn chat (conversation memory in your code)

Ollama does not automatically remember previous turns unless you send prior messages again.

```python
from ollama import chat

messages = [
    {"role": "system", "content": "You are a friendly Python tutor."},
    {"role": "user", "content": "What is a list in Python?"},
]

first = chat(model="llama3.2:3b", messages=messages)
assistant_reply = first["message"]["content"]
print("Assistant:", assistant_reply)

messages.append({"role": "assistant", "content": assistant_reply})
messages.append({"role": "user", "content": "Give one short example."})

second = chat(model="llama3.2:3b", messages=messages)
print("Assistant:", second["message"]["content"])
```

## 4.1 Keep the conversation between runs

If your script restarts, the in-memory `messages` list is lost. A simple beginner approach is to save chat history to a JSON file.

```python
import json
from pathlib import Path
from ollama import chat

HISTORY_FILE = Path("chat_history.json")


def load_messages() -> list[dict]:
    if HISTORY_FILE.exists():
        return json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
    return [{"role": "system", "content": "You are a helpful assistant."}]


def save_messages(messages: list[dict]) -> None:
    HISTORY_FILE.write_text(json.dumps(messages, ensure_ascii=False, indent=2), encoding="utf-8")


messages = load_messages()
user_text = input("You: ")
messages.append({"role": "user", "content": user_text})

response = chat(model="llama3.2:3b", messages=messages)
assistant_text = response["message"]["content"]
print("Assistant:", assistant_text)

messages.append({"role": "assistant", "content": assistant_text})
save_messages(messages)
```

Tip:
- Trim history when it grows too large (for example keep the last 20 messages).

## 4.2 How an agent can use the conversation

An agent can read the ongoing conversation and decide what to do next. A practical pattern is:
1. Keep the full user and assistant history in `messages`
2. Add a system instruction describing the agent behavior
3. Ask the model to return a small JSON action plan
4. Run that action in Python

```python
import json
from ollama import chat

messages = [
    {"role": "system", "content": "You are a task agent. Reply as JSON with fields: action and input."},
    {"role": "user", "content": "Summarize this text: Ollama makes local LLM usage simple."},
]

response = chat(
    model="llama3.2:3b",
    messages=messages,
    format="json",
)

plan = json.loads(response["message"]["content"])
print("Planned action:", plan)

# Example of how your agent could use the plan:
if plan.get("action") == "summarize":
    print("Agent executes summarize with input:", plan.get("input"))
```

Why this works:
- The conversation gives context
- The JSON plan makes agent behavior easier to control in code

## 5. Streaming output (better UX)

Use streaming when you want text to appear gradually.

```python
from ollama import chat

stream = chat(
    model="llama3.2:3b",
    messages=[{"role": "user", "content": "Write a short poem about coding."}],
    stream=True,
)

for chunk in stream:
    print(chunk["message"]["content"], end="", flush=True)

print()
```

## 6. Structured JSON output

For automation tasks, ask the model to return JSON only.

```python
import json
from ollama import chat

schema_hint = {
    "task": "string",
    "priority": "low|medium|high",
    "estimated_minutes": "integer",
}

prompt = f"""
Convert this request into JSON with this shape:
{json.dumps(schema_hint, indent=2)}
Request: 'Prepare slides for Monday and include 3 demo screenshots.'
Return JSON only.
"""

response = chat(
    model="llama3.2:3b",
    messages=[{"role": "user", "content": prompt}],
    format="json",
)

data = json.loads(response["message"]["content"])
print(data)
```

Tip:
- Always validate model JSON in production code.

## 7. Simple error handling

```python
from ollama import chat

try:
    response = chat(
        model="llama3.2:3b",
        messages=[{"role": "user", "content": "Say hello"}],
    )
    print(response["message"]["content"])
except Exception as e:
    print("Ollama call failed:", e)
    print("Check that Ollama is running and the model is pulled.")
```

## 8. Common beginner issues

1. Connection refused
   - Cause: Ollama server is not running
   - Fix: Start Ollama app or run `ollama serve`

2. Model not found
   - Cause: Model not downloaded
   - Fix: `ollama pull llama3.2:3b`

3. Slow responses
   - Cause: Model too large for your hardware
   - Fix: Use a smaller model (for example `llama3.2:1b`)

## 9. Practical next steps

1. Turn one of your existing scripts into a small CLI chat app
2. Add streaming so users see output immediately
3. Add JSON output for tasks like classification or extraction
4. Combine Ollama with your RAG examples in this repository

## 10. Quick reference

- Install package: `pip install ollama`
- Pull model: `ollama pull llama3.2:3b`
- Start server (Linux): `ollama serve`
- Basic call in Python: `chat(model=..., messages=[...])`
- Streaming: `stream=True`
- JSON mode: `format="json"`
