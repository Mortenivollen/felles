# Undervisningsplan (Komprimert 2 dager)

## Mål
Gi nybegynnere et komplett, praktisk løp fra lokal modellkjøring til RAG og agenter på to intensive dager.

## Læringsutbytte
1. Kjøre lokal modell med Ollama.
2. Lage enkle LangChain-flyter.
3. Bygge grunnleggende RAG.
4. Forstå verktøyagenter og LangGraph.
5. Se MCP og multi-agent i praksis.

## Dag 1 (09:00-15:30)

### 09:00-09:45 Oppstart og miljø
- Verifiser miljø og modeller.
- Kjør grunnleggende demo med lokale modellkall.
- Filer: Part1_app1.py, Part1_app2.py, gpu_verify.py.

### 09:45-10:45 Grunnleggende prompting
- Øvelse: Exercise 1.
- Fokus: input, output, feilhåndtering, modellvalg.

### 11:00-12:00 Strukturert output og persona
- Øvelser: Exercise 2 og Exercise 4.
- Fokus: JSON-output, promptstruktur, persona-modell.
- Filer: Part1_app3.py, Part1_app4.py, categorizer.py.

### 12:45-14:00 RAG-introduksjon
- Øvelse: Exercise 3.
- Fokus: chunking, embeddings, retrieval, grounded svar.
- Filer: part3_rag1.py, Part3_rag2.py.

### 14:00-15:30 RAG i enkel UI
- Demo/minipraksis: Part3_rag3_streamlit.py.
- Minioppgaver fra micro_exercises.md (RAG-blokk).

## Dag 2 (09:00-15:30)

### 09:00-10:30 Verktøyagent og LangGraph
- Øvelser: Exercise 5 og Exercise 6.
- Fokus: tool-calls, routing, state og noder.
- Filer: Part4_langchain_agent_tools.py, Part4_langgraph_agent.py.

### 10:45-12:00 Multi-agent og orkestrering
- Øvelse: Exercise 7.
- Fokus: supervisor, spesialistroller, writer-node.
- Fil: Part5_multi_agent.py.

### 12:45-13:45 MCP-integrasjon
- Øvelse: Exercise 8.
- Fokus: tool discovery, ekstern verktøybruk via MCP.
- Fil: Part5_mcp_ollama_langchain_langgraph.py.

### 13:45-15:00 Capstone
- Case: itil_log_agent.py.
- Gruppeoppgave: bygg en liten ende-til-ende flyt med tydelig ansvarsdeling.

### 15:00-15:30 Oppsummering og evaluering
- Demo per gruppe (5 min).
- Kort refleksjon: hva fungerte, hva var vanskelig, hva er neste steg.

## Leveranser fra deltakere
1. Minst én kjørbar RAG-løsning.
2. Minst én kjørbar agentløsning.
3. Kort muntlig forklaring av arkitekturvalg.
