# MCP + Ollama + LangChain + LangGraph: Practical Beginner Guide

This guide shows the smallest practical example of using an MCP server with Ollama, LangChain, and LangGraph.

You will learn how to:
- Connect to a remote MCP server
- Connect to MCP tools from LangChain
- Run a LangGraph agent with an Ollama model

## 1. Why MCP here?

MCP (Model Context Protocol) gives a standard way to expose tools.

In this demo:
1. A remote MCP server exposes tools
2. A LangGraph agent loads those tools through LangChain MCP adapters
3. ChatOllama decides when to use the tools

## 2. Prerequisites

1. Install and run Ollama
   - Windows/macOS: start the Ollama app
   - Linux: `ollama serve`
2. Pull a model
   - `ollama pull llama3.2:3b`
3. Install packages
   - `pip install mcp langchain-mcp-adapters langchain-ollama langgraph`

Optional in this repository:
- `pip install -r requirements.txt`

## 3. One-file demo script

Use this file:
- `mcp_ollama_langchain_langgraph_demo.py`

What it does:
- Connects to one remote MCP URL using `streamable_http` transport
- Uses `REMOTE_MCP_URL` environment variable (default: `https://learn.microsoft.com/api/mcp`)

The remote MCP server should expose useful tools (for example time, calculator, file search, etc.).

## 4. Run the demo

From project root:
- Optional: set your endpoint
   - PowerShell: `$env:REMOTE_MCP_URL="https://learn.microsoft.com/api/mcp"`
- `python mcp_ollama_langchain_langgraph_demo.py`

Expected flow:
1. Script connects to the remote MCP server
2. Agent asks remote tools when needed
3. Agent prints one short final answer

## 5. Common beginner issues

1. `ModuleNotFoundError` for MCP or adapters
   - Fix: install required packages again
2. Remote MCP server not reachable
   - Fix: verify URL, server status, and firewall/network rules
3. Ollama not reachable
   - Fix: start Ollama app or run `ollama serve`
4. Model not found
   - Fix: run `ollama pull llama3.2:3b`

## 6. Practical next step

Add authentication headers and a second remote MCP server entry, then route specific tasks to each server toolset.
