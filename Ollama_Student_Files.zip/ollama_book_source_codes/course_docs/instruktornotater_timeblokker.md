# Instruktornotater Per Timeblokk

Dette dokumentet er laget for undervisere og inneholder praktiske notater per blokk.

## Før kursstart (30 min)
- Sjekk at venv er aktivt.
- Bekreft modeller i Ollama.
- Kjør et kort testprompt for å sikre respons.
- Plan B: ha ferdigkjørte outputs for fallback ved nettverks- eller modellproblemer.

## Blokk 1 - Introduksjon
Mål:
- Etablere hvorfor lokal AI er nyttig.

Instruktørgrep:
- Vis raskt forskjellen mellom enkel prompt og strukturert prompt.
- Hold teori kort (maks 15 min), gå tidlig til demo.

Vanlige utfordringer:
- Modell ikke lastet ned.
- Ollama-server ikke startet.

## Blokk 2 - Øvelse 1 og 2
Mål:
- Få alle til å produsere stabil output.

Instruktørgrep:
- Gi ferdig eksempelprompt før individuell tilpasning.
- La studentene sammenligne output ved ulik temperatur.

Observasjonspunkter:
- Leser de feilmeldinger?
- Forstår de forskjellen på rå tekst og JSON?

## Blokk 3 - Persona og kategorisering
Mål:
- Forstå effekten av systemrolle/persona.

Instruktørgrep:
- Be studentene bruke samme input med to ulike personas.
- Diskuter kvalitetskriterier: klarhet, struktur, konsistens.

## Blokk 4 - RAG
Mål:
- Forstå retrieval før generering.

Instruktørgrep:
- Visualiser pipeline: chunk -> embedding -> query -> context -> answer.
- Be studentene skrive ut top-k chunks før svar.

Vanlige utfordringer:
- For store chunks gir svake treff.
- Manglende grounding i prompt.

## Blokk 5 - Agenter med verktøy
Mål:
- Forstå når verktøy brukes og når de ikke brukes.

Instruktørgrep:
- Bruk én prompt som trenger verktøy og én som ikke gjør det.
- Vis tool messages i enkel logger/print.

## Blokk 6 - LangGraph
Mål:
- Forstå noder, edges og state.

Instruktørgrep:
- Tegn opp grafen på tavle før kode.
- Koble hvert kodeavsnitt til graftegningen.

## Blokk 7 - Multi-agent
Mål:
- Forstå ansvarsdeling i roller.

Instruktørgrep:
- La studenter foreslå rutevalg før de ser modellen velge.
- Diskuter hvorfor writer-node kan forbedre sluttresultat.

## Blokk 8 - MCP og capstone
Mål:
- Se ekstern verktøyintegrasjon i praksis.

Instruktørgrep:
- Hold MCP-demo kort og konkret.
- Bruk resten av tiden på capstone med tydelige leveransekrav.

## Avslutning
- Hver gruppe presenterer én ting som fungerte godt.
- Hver gruppe presenterer én ting de ville forbedret.
- Oppsummer progresjon fra enkel prompt til orkestrert agentflyt.
