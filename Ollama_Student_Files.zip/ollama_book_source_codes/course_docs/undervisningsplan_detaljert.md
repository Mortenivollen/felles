# Detaljert Undervisningsplan (3 dager)

## Målgruppe
Nybegynnere som skal lære lokal LLM-bruk med Ollama, videre med LangChain, RAG, agenter, LangGraph og MCP.

## Læringsmål for hele kurset
1. Kunne kjøre lokale LLM-modeller med Ollama.
2. Kunne bygge enkle chains i LangChain.
3. Kunne bygge og forklare en grunnleggende RAG-pipeline.
4. Kunne implementere verktøybrukende agenter.
5. Kunne bygge en enkel multi-agent flyt med LangGraph.
6. Forstå MCP-konseptet og bruke eksterne verktøy via agent.

## Før kursstart (instruktør)
1. Verifiser miljø med gpu_verify.py.
2. Installer avhengigheter: pip install -r requirements.txt.
3. Sørg for at ollama serve kjører.
4. Last ned modeller: llama3.2 og mxbai-embed-large.
5. Verifiser at start_exercises.py åpner meny uten feil.

## Dag 1 - Grunnlag: Ollama og LangChain

### 09:00-09:45 Introduksjon
- Tema: Lokal AI, modellvalg, hva som kjøres lokalt vs eksternt.
- Demo: Part1_app1.py og Part1_app2.py.
- Output: Deltakerne ser forskjell på REST/SDK og enkel promptflyt.

### 09:45-10:30 Praktisk blokk A
- Oppgave: Exercise 1.
- Fokus: prompt, feilhåndtering, modellkall.
- Leveranse: kjørbar script med tydelig output.

### 10:45-11:30 Persona og strukturering
- Demo: Part1_app3.py, Part1_app4.py, categorizer.py.
- Oppgave: Exercise 4 (starter + løsning).
- Leveranse: egendefinert persona og kategorisert resultat.

### 12:30-13:30 LangChain grunnmur
- Demo: Part2_app1.py og Part2_app2.py.
- Oppgave: Exercise 2.
- Fokus: prompt template, parser, robust JSON-output.

### 13:45-14:30 UI-miniblokk
- Demo: Part2_app3.py.
- Minioppgaver: micro_exercises.md Block B.
- Leveranse: liten forbedring i UI eller validering.

### 14:30-15:00 Oppsummering dag 1
- Sjekkpunkter:
  - Kan alle kjøre lokale modellkall?
  - Kan alle produsere strukturert output?

## Dag 2 - RAG og agentmønstre

### 09:00-10:00 RAG-konsept og første pipeline
- Demo: part3_rag1.py og Part3_rag2.py.
- Oppgave: Exercise 3.
- Fokus: chunking, embeddings, retrieval, grounded svar.

### 10:15-11:00 RAG UI
- Demo: Part3_rag3_streamlit.py.
- Minioppgaver: micro_exercises.md Block C.
- Leveranse: visning av retrieved chunks i UI/CLI.

### 12:00-13:00 Verktøyagent i LangChain
- Demo: Part4_langchain_agent_tools.py.
- Oppgave: Exercise 5.
- Fokus: tool calls, sikker kalkulator, kontrollert loop.

### 13:15-14:15 LangGraph agentloop
- Demo: Part4_langgraph_agent.py.
- Oppgave: Exercise 6.
- Fokus: state, node, edge, conditional routing.

### 14:15-15:00 Oppsummering dag 2
- Sjekkpunkter:
  - Kan alle forklare forskjellen på chain og agent?
  - Kan alle bygge model -> tools -> model flyt?

## Dag 3 - Multi-agent og MCP

### 09:00-10:00 Multi-agent arkitektur
- Demo: Part5_multi_agent.py.
- Oppgave: Exercise 7.
- Fokus: supervisor, spesialistagenter, writer-node.

### 10:15-11:00 Capstone-case
- Demo: itil_log_agent.py.
- Fokus: praktisk orkestrering med RAG og domene språk (ITIL).
- Leveranse: studentene forklarer flyten steg for steg.

### 12:00-13:00 MCP introduksjon
- Demo: Part5_mcp_ollama_langchain_langgraph.py.
- Oppgave: Exercise 8.
- Fokus: tool discovery, agent invoke, feilhåndtering.

### 13:15-14:15 Integrert gruppeoppgave
- Oppgave:
  - Velg ett case.
  - Bruk minst én agent, ett verktøy og én retrieval-kilde.
- Leveranse: 5 minutters gruppedemo.

### 14:15-15:00 Avslutning og evaluering
- Vurdering:
  - Kode kjører
  - Output er forståelig
  - Teamet kan forklare valg i design
- Neste steg:
  - Utvide med egne domene-datasett
  - Legge på testbarhet og logging

## Vurderingsmatrise (enkelt)

| Kriterium | 1 | 2 | 3 |
|---|---|---|---|
| Kjørbarhet | Kjører ikke | Kjører delvis | Kjører stabilt |
| Kodeforståelse | Uklar flyt | Delvis forklart | Tydelig forklart |
| Agentbruk | Ingen/feil | Enkel bruk | Riktig og begrunnet |
| RAG-kvalitet | Hallusinasjoner | Delvis grounded | Grounded med kildebevissthet |
| Samarbeid/presentasjon | Utydelig | Ok | Klar og strukturert |

## Kobling til øvelser
1. Dag 1: Exercise 1, 2, 4
2. Dag 2: Exercise 3, 5, 6
3. Dag 3: Exercise 7, 8
