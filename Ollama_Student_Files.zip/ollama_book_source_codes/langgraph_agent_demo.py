from datetime import datetime
from typing import Annotated, TypedDict

from langchain_core.messages import AnyMessage
from langchain_core.tools import tool
from langchain_ollama import ChatOllama
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode


@tool
def get_current_time(_: str = "") -> str:
    """Return the current local time."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


@tool
def calculate(expression: str) -> str:
    """Evaluate a simple math expression like '12 * (3 + 4)'."""
    allowed = set("0123456789+-*/(). %")
    if not set(expression) <= allowed:
        return "Error: unsupported characters in expression."

    try:
        result = eval(expression, {"__builtins__": {}}, {})
        return str(result)
    except Exception as exc:
        return f"Error: {exc}"


TOOLS = [get_current_time, calculate]


class AgentState(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]


llm = ChatOllama(model="llama3.2:3b", temperature=0)
llm_with_tools = llm.bind_tools(TOOLS)


def call_model(state: AgentState) -> AgentState:
    response = llm_with_tools.invoke(state["messages"])
    return {"messages": [response]}


def route_after_model(state: AgentState) -> str:
    last_message = state["messages"][-1]
    tool_calls = getattr(last_message, "tool_calls", None) or []
    if tool_calls:
        return "tools"
    return "end"


def build_app():
    workflow = StateGraph(AgentState)
    workflow.add_node("model", call_model)
    workflow.add_node("tools", ToolNode(TOOLS))

    workflow.set_entry_point("model")
    workflow.add_conditional_edges(
        "model",
        route_after_model,
        {
            "tools": "tools",
            "end": END,
        },
    )
    workflow.add_edge("tools", "model")

    return workflow.compile()


def run_examples(app):
    questions = [
        "What time is it?",
        "What is (1250 * 19) / 100? Explain in one sentence.",
        "What is the capital of Norway?",
    ]

    system = (
        "You are a practical assistant. "
        "Use tools when needed for time and math. "
        "If no tool is needed, answer directly."
    )

    for q in questions:
        print(f"\nUser: {q}")
        result = app.invoke(
            {
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user", "content": q},
                ]
            }
        )
        final = result["messages"][-1]
        print("Assistant:", final.content)


def run_chat(app):
    print("\nInteractive mode. Type 'exit' to stop.")
    conversation = [
        {
            "role": "system",
            "content": "You are a practical assistant that can use tools.",
        }
    ]

    while True:
        user_text = input("You: ").strip()
        if user_text.lower() in {"exit", "quit"}:
            print("Goodbye.")
            break

        conversation.append({"role": "user", "content": user_text})
        result = app.invoke({"messages": conversation})

        assistant_text = result["messages"][-1].content
        print("Assistant:", assistant_text)

        conversation.append({"role": "assistant", "content": assistant_text})
        if len(conversation) > 21:
            conversation = [conversation[0]] + conversation[-20:]


if __name__ == "__main__":
    app = build_app()
    run_examples(app)
    run_chat(app)
