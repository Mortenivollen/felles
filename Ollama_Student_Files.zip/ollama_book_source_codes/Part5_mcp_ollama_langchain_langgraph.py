import asyncio
import os

from langchain_ollama import ChatOllama
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain.agents import create_agent


MODEL_NAME = "llama3.2"
REMOTE_MCP_URL = os.getenv("REMOTE_MCP_URL", "https://learn.microsoft.com/api/mcp")


async def run_agent_demo() -> None:
    """Run a LangGraph agent that uses remote MCP tools and an Ollama model."""

    # MultiServerMCPClient connects to one or more MCP servers.
    # Each entry in the dict is a named server connection.
    # "remote_demo" is just a label we choose — it can be anything.
    # "url" is the HTTP endpoint where the MCP server is running.
    # "transport" tells the client how to communicate with the server;
    #   "streamable_http" means it uses standard HTTP requests (no WebSocket needed).
    client = MultiServerMCPClient(
        {
            "remote_demo": {
                "url": REMOTE_MCP_URL,
                "transport": "streamable_http",
            }
        }
    )

    # Ask the MCP server what tools it offers.
    # The server responds with a list of tool definitions (name, description, input schema).
    # These are automatically converted into LangChain-compatible tool objects
    # so the agent can call them just like any other Python function.
    # "await" is used because this is a network request that takes some time to complete.
    #
    # It knows WHERE to fetch from because "client" was already configured above
    # with the server URL (REMOTE_MCP_URL) and transport ("streamable_http").
    # get_tools() simply connects to that URL and asks the server:
    # "what tools do you provide?" — following the MCP protocol.
    tools = await client.get_tools()

    llm = ChatOllama(model=MODEL_NAME, temperature=0)

    query = (
        "What course day is this demo for, and what is 12 * 7? "
        "Use tools when useful and answer briefly."
    )

    result = await create_agent(
        llm,
        tools,
        system_prompt="You are a practical assistant. Use MCP tools when needed.",
    ).ainvoke({"messages": [{"role": "user", "content": query}]})

    final_message = result["messages"][-1]
    final_text = getattr(final_message, "content", str(final_message))

    print("Remote MCP URL:", REMOTE_MCP_URL)
    print("User:", query)
    print("Assistant:", final_text)


if __name__ == "__main__":
    asyncio.run(run_agent_demo())
