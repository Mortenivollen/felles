from datetime import datetime
from typing import Annotated, TypedDict

# AnyMessage is a base type that covers all LangChain message kinds
# (HumanMessage, AIMessage, ToolMessage, etc.)
from langchain_core.messages import AnyMessage

# @tool decorator turns a regular Python function into a tool the LLM can call
from langchain_core.tools import tool

# ChatOllama connects to a locally running Ollama model
from langchain_ollama import ChatOllama

# StateGraph is the core LangGraph class for building agent workflows as graphs
# END is a special marker that tells the graph "we're done, stop here"
from langgraph.graph import END, StateGraph

# add_messages is a special reducer: instead of replacing the messages list,
# it appends new messages to the existing ones whenever the state is updated
from langgraph.graph.message import add_messages

# ToolNode is a pre-built graph node that automatically runs tool calls
# found in the last LLM message and returns the results as ToolMessages
from langgraph.prebuilt import ToolNode


# --- Define the tools the LLM is allowed to use ---

@tool
def get_current_time(_: str = "") -> str:
    """Return the current local time."""
    # strftime formats the datetime as a readable string, e.g. "2026-03-16 14:30:00"
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


@tool
def calculate(expression: str) -> str:
    """Evaluate a simple math expression like '12 * (3 + 4)'."""
    # Only allow safe characters to prevent code injection
    allowed = set("0123456789+-*/(). %")
    if not set(expression) <= allowed:
        return "Error: unsupported characters in expression."

    try:
        # eval() computes the math expression.
        # Passing empty dicts blocks access to built-in Python functions
        # so it cannot run arbitrary/dangerous code.
        result = eval(expression, {"__builtins__": {}}, {})
        return str(result)
    except Exception as exc:
        return f"Error: {exc}"


# List of all tools we want to expose to the LLM
TOOLS = [get_current_time, calculate]


# --- Define the graph state ---

# AgentState is the "memory" of the graph — it is passed between every node.
# TypedDict means it behaves like a regular dict but with type hints.
class AgentState(TypedDict):
    # Annotated[..., add_messages] tells LangGraph to *append* new messages
    # rather than overwrite the list each time a node returns messages.
    messages: Annotated[list[AnyMessage], add_messages]


# --- Set up the LLM ---

# temperature=0 makes the model deterministic (same input → same output)
llm = ChatOllama(model="llama3.2", temperature=0)

# bind_tools informs the LLM about the available tools so it can decide
# to call them and include tool call requests in its responses
llm_with_tools = llm.bind_tools(TOOLS)


# --- Define graph nodes ---

# A node is just a function that receives the current state and returns
# a (partial) state update. LangGraph merges the update into the state.

def call_model(state: AgentState) -> AgentState:
    # Invoke the LLM with all messages seen so far
    response = llm_with_tools.invoke(state["messages"])
    # Return the new message; add_messages will append it to the list
    return {"messages": [response]}


# --- Define routing logic ---

def route_after_model(state: AgentState) -> str:
    """Decide what to do after the model node runs."""
    last_message = state["messages"][-1]  # The most recent LLM response

    # tool_calls is populated when the LLM wants to call one or more tools
    tool_calls = getattr(last_message, "tool_calls", None) or []

    if tool_calls:
        return "tools"  # Go to the tools node to execute the tool calls
    return "end"        # No tool calls — the LLM gave a final answer, stop


# --- Build the graph ---

def build_app():
    # Create a new graph whose nodes share AgentState as their state
    workflow = StateGraph(AgentState)

    # Register the two nodes: "model" calls the LLM, "tools" runs tool calls
    workflow.add_node("model", call_model)
    workflow.add_node("tools", ToolNode(TOOLS))

    # The graph always starts at the "model" node
    workflow.set_entry_point("model")

    # After "model" runs, call route_after_model to decide where to go next.
    # The dict maps return values of the router to node names (or END).
    workflow.add_conditional_edges(
        "model",
        route_after_model,
        {
            "tools": "tools",  # LLM requested tools → run them
            "end": END,        # LLM gave final answer → finish
        },
    )

    # After the tools node finishes, always go back to the model node so the
    # LLM can see the tool results and compose a final answer
    workflow.add_edge("tools", "model")

    # compile() validates the graph and returns a runnable app object
    return workflow.compile()


# --- Example questions (non-interactive) ---

def run_examples(app):
    questions = [
        "What time is it?",
        "What is (1250 * 19) / 100? Explain in one sentence.",
        "What is the capital of Norway?",
    ]

    system = (
        "You are a practical assistant. "
        "Use tools when needed for time and math. "
        "If no tool is needed, answer directly."
    )

    for q in questions:
        print(f"\nUser: {q}")
        # app.invoke runs the full graph from start to END for one turn
        result = app.invoke(
            {
                "messages": [
                    {"role": "system", "content": system},  # Background instructions
                    {"role": "user", "content": q},         # The actual question
                ]
            }
        )
        # The last message in the list is always the final LLM answer
        final = result["messages"][-1]
        print("Assistant:", final.content)


# --- Interactive chat (conversational) ---

def run_chat(app):
    print("\nInteractive mode. Type 'exit' to stop.")

    # Keep a running list of all messages so the LLM has conversation history.
    # The system message at index 0 always stays to guide the LLM's behaviour.
    conversation = [
        {
            "role": "system",
            "content": "You are a practical assistant that can use tools.",
        }
    ]

    while True:
        user_text = input("You: ").strip()
        if user_text.lower() in {"exit", "quit"}:
            print("Goodbye.")
            break

        # Add the user's message to history, then run the full graph
        conversation.append({"role": "user", "content": user_text})
        result = app.invoke({"messages": conversation})

        # Extract and display the final answer
        assistant_text = result["messages"][-1].content
        print("Assistant:", assistant_text)

        # Save the assistant's reply so future turns have full context
        conversation.append({"role": "assistant", "content": assistant_text})

        # Cap history to avoid sending too many tokens to the LLM.
        # Always keep the system message (index 0) + the last 20 messages.
        if len(conversation) > 21:
            conversation = [conversation[0]] + conversation[-20:]


if __name__ == "__main__":
    app = build_app()
    run_examples(app)
    run_chat(app)
