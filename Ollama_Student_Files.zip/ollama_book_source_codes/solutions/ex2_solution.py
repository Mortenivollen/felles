"""
Exercise 2 Solution — LangChain pipeline with ChatOllama and structured output

Goal:
- Build a small LangChain pipeline using ChatOllama and ChatPromptTemplate.
- Parse the model output into structured JSON using StrOutputParser.

Prerequisites:
- Ollama server running: `ollama serve`
- Model pulled: `ollama pull llama3.2`
- Python packages: `pip install langchain-core langchain-community langchain-ollama`

Run:
- python solutions/ex2_solution.py
"""

import json
from typing import Any, Dict

from langchain_ollama import ChatOllama
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser


MODEL_NAME = "llama3.2"


def build_chain():
    # Prompt: ask the model to classify a short review into categories
    system = (
        "You are a helpful classifier. Return valid JSON with keys: "
        "sentiment (positive|neutral|negative), aspects (list of strings), and summary (string)."
    )
    human = (
        "Classify the following product review: '{review}'.\n"
        "Only return JSON, no extra text."
    )

    prompt = ChatPromptTemplate.from_messages(
        [("system", system), ("human", human)]
    )

    llm = ChatOllama(model=MODEL_NAME, temperature=0.2)
    parser = StrOutputParser()

    # Compose: prompt → llm → string parser
    chain = prompt | llm | parser
    return chain


def main() -> int:
    review = (
        "The battery life is great, but the screen scratches easily."
    )

    chain = build_chain()
    raw = chain.invoke({"review": review})

    # Try to coerce to JSON; if it fails, just print raw
    try:
        data: Dict[str, Any] = json.loads(raw)
        print("Structured output (JSON):")
        print(json.dumps(data, indent=2, ensure_ascii=False))
    except Exception:
        print("Model returned non-JSON text; raw output:")
        print(raw)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
