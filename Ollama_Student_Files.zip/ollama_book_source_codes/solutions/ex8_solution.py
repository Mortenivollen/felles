"""Exercise 8 solution - MCP tools with Ollama agent."""

import asyncio
import os

from langchain.agents import create_agent
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_ollama import ChatOllama

MODEL_NAME = "llama3.2"
REMOTE_MCP_URL = os.getenv("REMOTE_MCP_URL", "https://learn.microsoft.com/api/mcp")


async def run_demo() -> None:
    client = MultiServerMCPClient(
        {
            "remote_demo": {
                "url": REMOTE_MCP_URL,
                "transport": "streamable_http",
            }
        }
    )

    tools = await client.get_tools()
    llm = ChatOllama(model=MODEL_NAME, temperature=0)

    query = "What course day is this demo for, and what is 12 * 7? Use tools when useful."
    agent = create_agent(
        llm,
        tools,
        system_prompt="You are a practical assistant. Use MCP tools when needed.",
    )
    result = await agent.ainvoke({"messages": [{"role": "user", "content": query}]})
    final_message = result["messages"][-1]

    print("MCP URL:", REMOTE_MCP_URL)
    print("Loaded tools:", len(tools))
    print("User:", query)
    print("Assistant:", getattr(final_message, "content", str(final_message)))


def main() -> int:
    try:
        asyncio.run(run_demo())
        return 0
    except Exception as exc:
        print("Error:", exc)
        print("Check REMOTE_MCP_URL and ensure Ollama is running.")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
