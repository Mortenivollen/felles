"""Exercise 7 solution - Supervisor and specialist multi-agent."""

from typing import Annotated, Literal, TypedDict

from langchain_core.messages import AnyMessage, HumanMessage, SystemMessage
from langchain_ollama import ChatOllama
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages

MODEL_NAME = "llama3.2"

supervisor_llm = ChatOllama(model=MODEL_NAME, temperature=0)
math_llm = ChatOllama(model=MODEL_NAME, temperature=0)
fact_llm = ChatOllama(model=MODEL_NAME, temperature=0)
writer_llm = ChatOllama(model=MODEL_NAME, temperature=0.2)


class AgentState(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]
    next_agent: str


SUPERVISOR_SYSTEM = (
    "You are a supervisor that routes tasks. "
    "Reply with only one word: math_agent or fact_agent. "
    "Use math_agent for arithmetic or numeric computation tasks."
)


def supervisor_node(state: AgentState) -> AgentState:
    response = supervisor_llm.invoke([SystemMessage(content=SUPERVISOR_SYSTEM), *state["messages"]])
    decision = response.content.strip().lower()
    if decision not in {"math_agent", "fact_agent"}:
        decision = "fact_agent"
    return {"next_agent": decision}


def math_agent_node(state: AgentState) -> AgentState:
    response = math_llm.invoke([
        SystemMessage(content="You are a math specialist. Solve clearly and briefly."),
        *state["messages"],
    ])
    response.content = f"[Math Agent] {response.content}"
    return {"messages": [response]}


def fact_agent_node(state: AgentState) -> AgentState:
    response = fact_llm.invoke([
        SystemMessage(content="You are a factual assistant. If unsure, say so."),
        *state["messages"],
    ])
    response.content = f"[Fact Agent] {response.content}"
    return {"messages": [response]}


def writer_node(state: AgentState) -> AgentState:
    response = writer_llm.invoke([
        SystemMessage(content="You are a writer. Produce one polished final answer for the user."),
        *state["messages"],
    ])
    return {"messages": [response]}


def route_from_supervisor(state: AgentState) -> Literal["math_agent", "fact_agent"]:
    return "math_agent" if state.get("next_agent") == "math_agent" else "fact_agent"


def build_app():
    graph = StateGraph(AgentState)
    graph.add_node("supervisor", supervisor_node)
    graph.add_node("math_agent", math_agent_node)
    graph.add_node("fact_agent", fact_agent_node)
    graph.add_node("writer", writer_node)

    graph.set_entry_point("supervisor")
    graph.add_conditional_edges(
        "supervisor",
        route_from_supervisor,
        {"math_agent": "math_agent", "fact_agent": "fact_agent"},
    )
    graph.add_edge("math_agent", "writer")
    graph.add_edge("fact_agent", "writer")
    graph.add_edge("writer", END)

    return graph.compile()


def ask(app, question: str) -> str:
    state = {"messages": [HumanMessage(content=question)], "next_agent": ""}
    final_state = app.invoke(state)
    return final_state["messages"][-1].content


def main() -> int:
    app = build_app()
    for q in [
        "What is 345 multiplied by 78?",
        "What is the capital of Japan?",
    ]:
        print("\nQuestion:", q)
        print("Answer:", ask(app, q))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
