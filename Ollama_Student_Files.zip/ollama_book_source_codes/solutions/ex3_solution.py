"""
Exercise 3 Solution — Minimal CLI RAG with LangChain + Chroma + Ollama

Goal:
- Build a simple Retrieval-Augmented Generation (RAG) pipeline over a local text file.
- Use LangChain's RecursiveCharacterTextSplitter for chunking and OllamaEmbeddings for vectorization.
- Store embeddings in an in-memory Chroma collection and retrieve top-k chunks for answering.
- Generate the final answer with the Ollama SDK using the retrieved context.

Prerequisites:
- Ollama server running: `ollama serve`
- Models pulled: `ollama pull llama3.2` and `ollama pull mxbai-embed-large`
- Python packages:
  pip install ollama chromadb langchain-ollama langchain-community langchain-text-splitters

Run:
- python solutions/ex3_solution.py "What are the powers of Congress?"
"""

import sys
from pathlib import Path
from typing import List

import ollama
import chromadb
from langchain_ollama import OllamaEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter


LLM_MODEL = "llama3.2"
EMBED_MODEL = "mxbai-embed-large"
SOURCE_PATH = Path(__file__).resolve().parent.parent / "constitution.txt"


def load_text() -> str:
    if not SOURCE_PATH.exists():
        raise FileNotFoundError(f"Source file not found: {SOURCE_PATH}")
    return SOURCE_PATH.read_text(encoding="utf-8", errors="ignore")


def chunk_text(text: str) -> List[str]:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=800, chunk_overlap=100, separators=["\n\n", "\n", " "]
    )
    return splitter.split_text(text)


def build_vector_store(chunks: List[str]):
    embedder = OllamaEmbeddings(model=EMBED_MODEL)
    client = chromadb.Client()  # in-memory
    collection = client.create_collection(name="constitution")

    # Embed chunks and add to Chroma
    vectors = embedder.embed_documents(chunks)
    ids = [f"doc-{i}" for i in range(len(chunks))]
    collection.add(ids=ids, embeddings=vectors, documents=chunks)
    return collection, embedder


def retrieve_context(collection, embedder, question: str, k: int = 4) -> List[str]:
    qvec = embedder.embed_query(question)
    results = collection.query(query_embeddings=[qvec], n_results=k)
    docs = results.get("documents", [[]])[0]
    return docs


def answer_with_context(question: str, context_chunks: List[str]) -> str:
    context = "\n\n".join(context_chunks)
    prompt = (
        "Using the context below, answer the question concisely.\n"
        "If the answer is not in the context, say you don't know.\n\n"
        f"Context:\n{context}\n\n"
        f"Question: {question}\n"
    )
    result = ollama.generate(model=LLM_MODEL, prompt=prompt)
    return result.get("response", "")


def main() -> int:
    question = (
        "What are the powers of Congress?" if len(sys.argv) < 2 else " ".join(sys.argv[1:])
    )

    try:
        text = load_text()
        chunks = chunk_text(text)
        collection, embedder = build_vector_store(chunks)
        ctx = retrieve_context(collection, embedder, question, k=4)
        answer = answer_with_context(question, ctx)
        print("\n[Question]", question)
        print("\n[Retrieved Context Snippets]")
        for i, c in enumerate(ctx, 1):
            print(f"--- snippet {i} ---\n{c[:500]}\n")
        print("\n[Answer]\n", answer)
        return 0
    except Exception as exc:
        print("Error running RAG:", exc)
        print(
            "Check that Ollama server is running and models are pulled: 'llama3.2' and 'mxbai-embed-large'."
        )
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
