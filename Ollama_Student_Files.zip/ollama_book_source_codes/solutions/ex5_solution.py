"""Exercise 5 solution - LangChain tool agent."""

from datetime import datetime

from langchain_core.messages import HumanMessage, SystemMessage, ToolMessage
from langchain_core.tools import tool
from langchain_ollama import ChatOllama

MODEL_NAME = "llama3.2"


@tool
def get_current_time(_: str = "") -> str:
    """Return local date/time as text."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


@tool
def calculate(expression: str) -> str:
    """Evaluate a simple math expression like 12 * (3 + 4)."""
    allowed = set("0123456789+-*/(). %")
    if not set(expression) <= allowed:
        return "Error: unsupported characters in expression."

    try:
        value = eval(expression, {"__builtins__": {}}, {})
        return str(value)
    except Exception as exc:
        return f"Error: {exc}"


TOOLS = [get_current_time, calculate]
TOOLS_BY_NAME = {t.name: t for t in TOOLS}

llm = ChatOllama(model=MODEL_NAME, temperature=0)
llm_with_tools = llm.bind_tools(TOOLS)

SYSTEM_TEXT = (
    "You are a practical assistant. Use tools when needed for time and math. "
    "If no tool is needed, answer directly."
)


def run_turn(question: str) -> str:
    messages = [SystemMessage(content=SYSTEM_TEXT), HumanMessage(content=question)]

    ai_message = llm_with_tools.invoke(messages)
    messages.append(ai_message)

    if not ai_message.tool_calls:
        return ai_message.content

    for call in ai_message.tool_calls:
        tool_fn = TOOLS_BY_NAME.get(call["name"])
        tool_result = tool_fn.invoke(call["args"]) if tool_fn else f"Unknown tool: {call['name']}"
        messages.append(ToolMessage(content=str(tool_result), tool_call_id=call["id"]))

    final = llm_with_tools.invoke(messages)
    return final.content


def main() -> int:
    questions = [
        "What time is it right now?",
        "What is (1250 * 19) / 100?",
        "What is the capital of Norway?",
    ]

    for q in questions:
        print("\nUser:", q)
        print("Assistant:", run_turn(q))

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
