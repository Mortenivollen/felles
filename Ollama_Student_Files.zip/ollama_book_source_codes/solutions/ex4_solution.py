"""Exercise 4 solution - Persona model + categorizer."""

import ollama

BASE_MODEL = "llama3.2"
CUSTOM_MODEL = "travel_helper"

ITEMS = [
    "Passport",
    "T-shirt",
    "Toothbrush",
    "Phone Charger",
    "Raincoat",
    "Credit Card",
    "Socks",
    "Shampoo",
    "Laptop",
    "Travel Pillow",
]


def build_custom_model() -> None:
    modelfile = """
PARAMETER temperature 0.2
SYSTEM You are a practical travel packing assistant. Always categorize items clearly and keep output concise.
"""
    ollama.create(model=CUSTOM_MODEL, from_=BASE_MODEL, system=modelfile)


def categorize_items(items: list[str]) -> str:
    prompt = f"""
Categorize the following items into exactly these sections:
- Clothing
- Toiletries
- Electronics
- Documents
- Miscellaneous

Sort each section alphabetically and list only items from this list:
{items}
"""
    result = ollama.generate(model=CUSTOM_MODEL, prompt=prompt)
    return result.get("response", "").strip()


def main() -> int:
    try:
        build_custom_model()
        output = categorize_items(ITEMS)
        print("\nCategorized travel list:\n")
        print(output)
        return 0
    except Exception as exc:
        print("Error:", exc)
        print("Make sure Ollama is running and llama3.2 is pulled.")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
