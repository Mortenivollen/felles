"""
Exercise 1 Solution — Prompting with Ollama SDK

Goal:
- Use the Ollama Python SDK to generate text from a prompt using the local model "llama3.2".

Prerequisites:
- Ollama server running: `ollama serve`
- Model pulled once: `ollama pull llama3.2`
- Python package: `pip install ollama`

Run:
- python solutions/ex1_solution.py
"""

import sys
import ollama


MODEL_NAME = "llama3.2"


def main() -> int:
    prompt = (
        "Write a short haiku about snow and reflection."
        if len(sys.argv) < 2
        else " ".join(sys.argv[1:])
    )

    try:
        # Basic connectivity sanity check (optional): list known models
        _ = ollama.list()
    except Exception as exc:
        print(
            "Could not reach the Ollama server. Make sure it's running with 'ollama serve'."
        )
        print(f"Details: {exc}")
        return 1

    try:
        result = ollama.generate(model=MODEL_NAME, prompt=prompt)
        text = result.get("response", "")
        print("\n[Model]", MODEL_NAME)
        print("[Prompt]", prompt)
        print("[Response]\n", text)
        return 0
    except Exception as exc:
        print(
            f"Error generating with model '{MODEL_NAME}'. Ensure it's pulled via 'ollama pull {MODEL_NAME}'."
        )
        print(f"Details: {exc}")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
