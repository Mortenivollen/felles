"""Exercise 6 solution - LangGraph tool loop agent."""

from datetime import datetime
from typing import Annotated, TypedDict

from langchain_core.messages import AnyMessage
from langchain_core.tools import tool
from langchain_ollama import ChatOllama
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode

MODEL_NAME = "llama3.2"


@tool
def get_current_time(_: str = "") -> str:
    """Return local date/time as text."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


@tool
def calculate(expression: str) -> str:
    """Evaluate a simple arithmetic expression."""
    allowed = set("0123456789+-*/(). %")
    if not set(expression) <= allowed:
        return "Error: unsupported characters in expression."
    try:
        return str(eval(expression, {"__builtins__": {}}, {}))
    except Exception as exc:
        return f"Error: {exc}"


TOOLS = [get_current_time, calculate]
llm = ChatOllama(model=MODEL_NAME, temperature=0)
llm_with_tools = llm.bind_tools(TOOLS)


class AgentState(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]


def call_model(state: AgentState) -> AgentState:
    response = llm_with_tools.invoke(state["messages"])
    return {"messages": [response]}


def route_after_model(state: AgentState) -> str:
    last = state["messages"][-1]
    tool_calls = getattr(last, "tool_calls", None) or []
    return "tools" if tool_calls else "end"


def build_app():
    workflow = StateGraph(AgentState)
    workflow.add_node("model", call_model)
    workflow.add_node("tools", ToolNode(TOOLS))
    workflow.set_entry_point("model")
    workflow.add_conditional_edges("model", route_after_model, {"tools": "tools", "end": END})
    workflow.add_edge("tools", "model")
    return workflow.compile()


def main() -> int:
    app = build_app()

    prompts = [
        "What time is it?",
        "What is (480 + 120) / 3?",
        "What is the capital of Japan?",
    ]

    for p in prompts:
        state = {
            "messages": [
                {"role": "system", "content": "Use tools when needed for time and math."},
                {"role": "user", "content": p},
            ]
        }
        result = app.invoke(state)
        print("\nUser:", p)
        print("Assistant:", result["messages"][-1].content)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
