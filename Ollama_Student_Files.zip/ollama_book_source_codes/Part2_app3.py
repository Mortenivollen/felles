"""
app7.py — Minimal Streamlit app using the Ollama Python SDK (no REST requests).

Setup (Windows):
- Install: pip install ollama streamlit
- Start Ollama: ollama serve   # required for the SDK to connect locally
- Pull model (once): ollama pull llama3.2
- Run: streamlit run app7.py
"""

import streamlit as st
import ollama  # Using the Python SDK (no manual HTTP requests)

MODEL_NAME = "llama3.2"  # Default model for this repo

st.title("Ollama SDK Prompt Demo")

# Text area for user input
user_prompt = st.text_area("Enter a prompt:", height=120)

# Button to trigger generation via the SDK
if st.button("Generate response"):
    if not user_prompt.strip():
        st.warning("Please enter a prompt.")
    else:
        # st.spinner displays a temporary loading indicator while the enclosed block executes
        with st.spinner("Generating..."):
            try:
                # SDK call: returns a dict; 'response' contains the model's text
                result = ollama.generate(model=MODEL_NAME, prompt=user_prompt)
                st.success("Done")
                st.write(result.get("response", "").strip())
            except Exception as e:
                # Common issues: Ollama not running, model not pulled
                st.error(f"Error: {e}")