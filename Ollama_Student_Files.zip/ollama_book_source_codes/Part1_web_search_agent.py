# web_search_agent.py
#
# A beginner-friendly example showing how to build an AI agent
# that can search the internet using a local Ollama model.
#
# This script runs TWO rounds for the same question so beginners can
# clearly see the difference:
#
#   Round 1 — Plain LLM (no tools):
#     The model answers from its training data only.
#     It may give outdated or uncertain information.
#
#   Round 2 — Agent with web search:
#     The LLM decides to call a search tool, fetches live results,
#     and then gives a much more accurate, up-to-date answer.
#
# Requirements:
#   pip install langchain langchain-ollama langchain-community duckduckgo-search
#   Ollama must be running locally:  ollama serve
#   The model must be downloaded:    ollama pull llama3.2

from langchain_ollama import ChatOllama
from langchain_community.tools import DuckDuckGoSearchRun
from langchain.agents import create_agent
from langchain_core.messages import HumanMessage

# ── Configuration ─────────────────────────────────────────────
MODEL_NAME = "llama3.2"   # change to any model you have pulled in Ollama
# ──────────────────────────────────────────────────────────────

# The question we will ask in both rounds.
question = "What is the latest version of Python?"
print(f"Question: {question}\n")
print("=" * 60)

# ── Round 1: Plain LLM — no tools ─────────────────────────────
# ChatOllama talks to the Ollama server running on your machine.
# temperature=0 makes answers deterministic (less random).
llm = ChatOllama(model=MODEL_NAME, temperature=0)

# invoke() sends the message directly to the LLM and returns its reply.
# There are no tools here — the model can only use what it learned during training.
plain_response = llm.invoke([HumanMessage(content=question)])

print("\nRound 1 — Plain LLM (no internet access):")
print(plain_response.content)
print("=" * 60)

# ── Round 2: Agent with web search ────────────────────────────
# DuckDuckGoSearchRun is a free, no-API-key search tool.
# When the agent calls it, it searches DuckDuckGo and returns a text snippet.
search_tool = DuckDuckGoSearchRun()

# create_agent wraps the LLM and tools into a reasoning loop:
#   LLM thinks → decides to call a tool → gets result → thinks again → answers.
# system_prompt sets the agent's behaviour and role.
agent = create_agent(
    llm,
    tools=[search_tool],
    system_prompt=(
        "You are a helpful assistant. "
        "Use the search tool to look up current information when needed. "
        "Always answer in English."
    ),
)

# invoke() runs the full agent loop until it has a final answer.
result = agent.invoke({"messages": [{"role": "user", "content": question}]})

# result["messages"] contains every step the agent took.
# The last message is always the final answer.
final_answer = result["messages"][-1].content

print("\nRound 2 — Agent with web search (live results):")
print(final_answer)
print("=" * 60)
