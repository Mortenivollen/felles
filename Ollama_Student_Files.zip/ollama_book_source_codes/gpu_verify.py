import os
import sys
import time
import threading
import subprocess
import re

try:
    import ollama
except Exception as e:
    print("The 'ollama' Python package is not available in this environment.")
    print("Activate your venv and install requirements: pip install -r requirements.txt")
    sys.exit(1)


def find_nvidia_smi():
    candidates = [
        os.path.join(os.environ.get("ProgramFiles", r"C:\\Program Files"),
                     "NVIDIA Corporation", "NVSMI", "nvidia-smi.exe"),
        "nvidia-smi",
    ]
    for path in candidates:
        try:
            result = subprocess.run([path, "-h"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if result.returncode == 0 or result.returncode == 1:
                return path
        except Exception:
            continue
    return None


def query_gpu_info(smi_cmd):
    try:
        out = subprocess.check_output(
            [
                smi_cmd,
                "--query-gpu=name,driver_version,memory.total",
                "--format=csv,noheader"
            ],
            stderr=subprocess.DEVNULL,
        ).decode("utf-8", errors="ignore").strip()
        lines = [l.strip() for l in out.splitlines() if l.strip()]
        return lines
    except Exception:
        return []


def sample_gpu(smi_cmd, stop_event, samples):
    while not stop_event.is_set():
        try:
            out = subprocess.check_output(
                [
                    smi_cmd,
                    "--query-gpu=utilization.gpu,memory.used",
                    "--format=csv,noheader"
                ],
                stderr=subprocess.DEVNULL,
            ).decode("utf-8", errors="ignore").strip()
            # Example line: "12 %, 256 MiB"
            parts = [p.strip() for p in out.split(",")]
            util_pct = 0
            mem_mib = 0.0
            if parts:
                m = re.search(r"(\d+)", parts[0])
                if m:
                    util_pct = int(m.group(1))
            if len(parts) > 1:
                m = re.search(r"(\d+\.?\d*)", parts[1])
                if m:
                    mem_mib = float(m.group(1))
            samples.append((util_pct, mem_mib))
        except Exception:
            samples.append((0, 0.0))
        time.sleep(0.5)


def main():
    print("=== GPU + Ollama Verification ===")
    print(f"Python: {sys.version.split()[0]}")
    print(f"OLLAMA_NO_GPU: {os.environ.get('OLLAMA_NO_GPU', '<unset>')}")
    print(f"OLLAMA_NUM_GPU: {os.environ.get('OLLAMA_NUM_GPU', '<unset>')}")
    print()

    smi_cmd = find_nvidia_smi()
    if smi_cmd:
        print(f"Found nvidia-smi at: {smi_cmd}")
        gpu_lines = query_gpu_info(smi_cmd)
        if gpu_lines:
            print("Detected GPU(s):")
            for line in gpu_lines:
                print(f"  - {line}")
        else:
            print("Could not query detailed GPU info.")
    else:
        print("nvidia-smi not found on PATH. GPU sampling will be skipped.")
    print()

    # Check Ollama server availability
    try:
        _ = ollama.list()
        print("Ollama server reachable.")
    except Exception as e:
        print("Ollama server not reachable. Ensure Ollama desktop/server is running.")
        print(f"Error: {e}")
        sys.exit(2)
    print()

    # Try a small inference to observe GPU usage
    stop_event = threading.Event()
    samples = []
    sampler_thread = None
    if smi_cmd:
        sampler_thread = threading.Thread(target=sample_gpu, args=(smi_cmd, stop_event, samples), daemon=True)
        sampler_thread.start()

    prompt = "Write ~120 words that explain photosynthesis succinctly."
    print("Starting inference with model 'llama3.2'...")
    start = time.time()
    try:
        res = ollama.chat(
            model="llama3.2",
            messages=[{"role": "user", "content": prompt}],
        )
        msg = res.get("message", {}).get("content", "<no content>")
        print("Response (truncated):")
        print((msg[:400] + "...") if len(msg) > 400 else msg)
    except Exception as e:
        print("Inference failed. The model may not be pulled or VRAM may be insufficient.")
        print("Try: 'ollama pull llama3.2' or use a smaller/quantized model.")
        print(f"Error: {e}")
    finally:
        stop_event.set()
        if sampler_thread:
            sampler_thread.join(timeout=2.0)
    dur = time.time() - start
    print(f"Inference duration: {dur:.2f}s")

    if samples:
        max_util = max((u for u, _ in samples), default=0)
        max_mem = max((m for _, m in samples), default=0.0)
        print(f"Observed GPU peak utilization: {max_util}%")
        print(f"Observed GPU peak memory used: {max_mem:.0f} MiB")
        if max_util >= 10:
            print("Conclusion: GPU activity detected during inference.")
        else:
            print("Conclusion: Little/no GPU activity detected; workload may have used CPU.")
    else:
        print("No GPU samples collected.")


if __name__ == "__main__":
    main()
