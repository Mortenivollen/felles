"""
Exercise 8 starter - MCP tools with Ollama agent

TODOs:
1) Create MCP client
2) Fetch tools
3) Run agent with one query
"""

import asyncio
import os

from langchain.agents import create_agent
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_ollama import ChatOllama

MODEL_NAME = "llama3.2"
REMOTE_MCP_URL = os.getenv("REMOTE_MCP_URL", "https://learn.microsoft.com/api/mcp")


async def run_demo() -> None:
    # TODO: configure MultiServerMCPClient
    # TODO: await client.get_tools()
    # TODO: create agent and run one query
    raise NotImplementedError


def main() -> int:
    try:
        asyncio.run(run_demo())
        return 0
    except Exception as exc:
        print("Error:", exc)
        print("Check REMOTE_MCP_URL and ensure Ollama is running.")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
