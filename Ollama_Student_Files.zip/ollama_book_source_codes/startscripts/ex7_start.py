"""
Exercise 7 starter - Supervisor + specialists multi-agent

TODOs:
1) Implement supervisor route decision
2) Implement math specialist and fact specialist
3) Implement writer node and graph wiring
"""

from typing import Annotated, Literal, TypedDict

from langchain_core.messages import AnyMessage, HumanMessage, SystemMessage
from langchain_ollama import ChatOllama
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages

MODEL_NAME = "llama3.2"

supervisor_llm = ChatOllama(model=MODEL_NAME, temperature=0)
math_llm = ChatOllama(model=MODEL_NAME, temperature=0)
fact_llm = ChatOllama(model=MODEL_NAME, temperature=0)
writer_llm = ChatOllama(model=MODEL_NAME, temperature=0.2)


class AgentState(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]
    next_agent: str


def supervisor_node(state: AgentState) -> AgentState:
    # TODO: decide between math_agent and fact_agent
    # return {"next_agent": "..."}
    raise NotImplementedError


def math_agent_node(state: AgentState) -> AgentState:
    # TODO: answer as math specialist
    raise NotImplementedError


def fact_agent_node(state: AgentState) -> AgentState:
    # TODO: answer as fact specialist
    raise NotImplementedError


def writer_node(state: AgentState) -> AgentState:
    # TODO: polish output and return final response message
    raise NotImplementedError


def route_from_supervisor(state: AgentState) -> Literal["math_agent", "fact_agent"]:
    return "math_agent" if state.get("next_agent") == "math_agent" else "fact_agent"


def build_app():
    # TODO: create graph, add nodes/edges, compile
    raise NotImplementedError


def ask(app, question: str) -> str:
    state = {
        "messages": [HumanMessage(content=question)],
        "next_agent": "",
    }
    final_state = app.invoke(state)
    return final_state["messages"][-1].content


def main() -> int:
    app = build_app()
    for q in [
        "What is 345 multiplied by 78?",
        "What is the capital of Japan?",
    ]:
        print("\nQuestion:", q)
        print("Answer:", ask(app, q))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
