"""
Exercise 4 starter - Persona model + categorizer

TODOs:
1) Implement build_custom_model()
2) Implement categorize_items()
3) Run and compare with ex4_solution.py
"""

import ollama

BASE_MODEL = "llama3.2"
CUSTOM_MODEL = "travel_helper"

ITEMS = [
    "Passport",
    "T-shirt",
    "Toothbrush",
    "Phone Charger",
    "Raincoat",
    "Credit Card",
    "Socks",
    "Shampoo",
    "Laptop",
    "Travel Pillow",
]


def build_custom_model() -> None:
    # TODO: Create a model derived from BASE_MODEL using ollama.create
    # Hint: define a system prompt that asks for concise, practical structure.
    raise NotImplementedError


def categorize_items(items: list[str]) -> str:
    # TODO: call ollama.generate with CUSTOM_MODEL and a categorization prompt
    # Return generated text from result["response"]
    raise NotImplementedError


def main() -> int:
    try:
        build_custom_model()
        output = categorize_items(ITEMS)
        print("\nCategorized travel list:\n")
        print(output)
        return 0
    except Exception as exc:
        print("Error:", exc)
        print("Make sure Ollama is running and llama3.2 is pulled.")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
