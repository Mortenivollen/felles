"""
Exercise 6 starter - LangGraph tool loop agent

TODOs:
1) Implement tools
2) Implement call_model and routing function
3) Build graph with model and ToolNode
"""

from datetime import datetime
from typing import Annotated, TypedDict

from langchain_core.messages import AnyMessage
from langchain_core.tools import tool
from langchain_ollama import ChatOllama
from langgraph.graph import END, StateGraph
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode

MODEL_NAME = "llama3.2"


@tool
def get_current_time(_: str = "") -> str:
    """Return local date/time as text."""
    # TODO
    raise NotImplementedError


@tool
def calculate(expression: str) -> str:
    """Evaluate a simple arithmetic expression."""
    # TODO
    raise NotImplementedError


TOOLS = [get_current_time, calculate]
llm = ChatOllama(model=MODEL_NAME, temperature=0)
llm_with_tools = llm.bind_tools(TOOLS)


class AgentState(TypedDict):
    messages: Annotated[list[AnyMessage], add_messages]


def call_model(state: AgentState) -> AgentState:
    # TODO: invoke model with state messages and return appended response
    raise NotImplementedError


def route_after_model(state: AgentState) -> str:
    # TODO: inspect last message tool_calls
    # return "tools" when tool calls exist, else "end"
    raise NotImplementedError


def build_app():
    # TODO: register nodes, set entry point, add conditional edges, compile
    raise NotImplementedError


def main() -> int:
    app = build_app()

    prompts = [
        "What time is it?",
        "What is (480 + 120) / 3?",
        "What is the capital of Japan?",
    ]

    for p in prompts:
        state = {
            "messages": [
                {"role": "system", "content": "Use tools when needed for time and math."},
                {"role": "user", "content": p},
            ]
        }
        result = app.invoke(state)
        print("\nUser:", p)
        print("Assistant:", result["messages"][-1].content)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
