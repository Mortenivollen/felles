"""
Exercise 5 starter - LangChain tool agent

TODOs:
1) Implement tools
2) Bind tools to ChatOllama
3) Complete tool call round-trip in run_turn()
"""

from datetime import datetime

from langchain_core.messages import HumanMessage, SystemMessage, ToolMessage
from langchain_core.tools import tool
from langchain_ollama import ChatOllama

MODEL_NAME = "llama3.2"


@tool
def get_current_time(_: str = "") -> str:
    """Return local date/time as text."""
    # TODO
    raise NotImplementedError


@tool
def calculate(expression: str) -> str:
    """Evaluate a simple math expression like 12 * (3 + 4)."""
    # TODO: add safe character allow-list + eval with disabled builtins
    raise NotImplementedError


TOOLS = [get_current_time, calculate]
TOOLS_BY_NAME = {t.name: t for t in TOOLS}

llm = ChatOllama(model=MODEL_NAME, temperature=0)
llm_with_tools = llm.bind_tools(TOOLS)

SYSTEM_TEXT = (
    "You are a practical assistant. Use tools when needed for time and math. "
    "If no tool is needed, answer directly."
)


def run_turn(question: str) -> str:
    messages = [SystemMessage(content=SYSTEM_TEXT), HumanMessage(content=question)]

    # TODO 1: invoke llm_with_tools with messages
    # TODO 2: if no tool calls, return direct response text
    # TODO 3: execute requested tools and append ToolMessage per call
    # TODO 4: invoke llm_with_tools again and return final content
    raise NotImplementedError


def main() -> int:
    questions = [
        "What time is it right now?",
        "What is (1250 * 19) / 100?",
        "What is the capital of Norway?",
    ]

    for q in questions:
        print("\nUser:", q)
        print("Assistant:", run_turn(q))

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
