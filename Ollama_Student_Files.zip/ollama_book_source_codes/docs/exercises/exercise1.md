**Exercise 1 — Prompting with Ollama SDK**

- **Goal:** Build a small script that sends a prompt to a local Ollama model (`llama3.2`) and prints the response.
- **Prerequisites:**
  - Ollama server: `ollama serve`
  - Pull model once: `ollama pull llama3.2`
  - Python package: `pip install ollama`
- **Tasks:**
  - Call `ollama.generate(model='llama3.2', prompt='<your prompt>')`.
  - Print model name, prompt, and response.
  - Handle errors if the server is not reachable or the model is missing.
- **Acceptance Criteria:**
  - Script prints a coherent response from the model.
  - Graceful error message when Ollama isn't running.
- **Reference Solution:** [solutions/ex1_solution.py](solutions/ex1_solution.py)
- **Run:**

```powershell
# Using the repo venv
D:\kurs\datascience\EgneKurs\ollama_langchain_rag\ollama_book_source_codes\.venv\Scripts\python.exe solutions\ex1_solution.py "Write a haiku about winter sunlight."

# Or using system Python
python solutions/ex1_solution.py "Write a haiku about winter sunlight."
```
