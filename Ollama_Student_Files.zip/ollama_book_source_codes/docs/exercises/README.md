# Exercises Overview

Core course docs:
- [docs/workspace_oversikt.md](docs/workspace_oversikt.md) — folder and file overview
- [docs/undervisningsplan_detaljert.md](docs/undervisningsplan_detaljert.md) — detailed 3-day teaching plan
- [docs/undervisningsplan_detaljert.docx](docs/undervisningsplan_detaljert.docx) — Word version

- [docs/exercises/exercise1.md](docs/exercises/exercise1.md) — Prompting with Ollama SDK
- [docs/exercises/exercise2.md](docs/exercises/exercise2.md) — LangChain pipeline with structured JSON output
- [docs/exercises/exercise3.md](docs/exercises/exercise3.md) — Minimal CLI RAG over a local document
- [docs/exercises/exercise4.md](docs/exercises/exercise4.md) — Persona model and categorizer
- [docs/exercises/exercise5.md](docs/exercises/exercise5.md) — LangChain tool agent
- [docs/exercises/exercise6.md](docs/exercises/exercise6.md) — LangGraph tool loop agent
- [docs/exercises/exercise7.md](docs/exercises/exercise7.md) — Supervisor and specialist multi-agent
- [docs/exercises/exercise8.md](docs/exercises/exercise8.md) — MCP tools with Ollama agent

DOCX versions:
- [docs/exercises/exercise1.docx](docs/exercises/exercise1.docx)
- [docs/exercises/exercise2.docx](docs/exercises/exercise2.docx)
- [docs/exercises/exercise3.docx](docs/exercises/exercise3.docx)
- [docs/exercises/exercise4.docx](docs/exercises/exercise4.docx)
- [docs/exercises/exercise5.docx](docs/exercises/exercise5.docx)
- [docs/exercises/exercise6.docx](docs/exercises/exercise6.docx)
- [docs/exercises/exercise7.docx](docs/exercises/exercise7.docx)
- [docs/exercises/exercise8.docx](docs/exercises/exercise8.docx)

Companion docs:
- [docs/exercises/script_mapping.md](docs/exercises/script_mapping.md) — script-to-exercise mapping table
- [docs/exercises/micro_exercises.md](docs/exercises/micro_exercises.md) — short 15-20 minute practice tasks

Starters and solutions:
- Starters for exercises 4-8 are in [startscripts/](startscripts/)
- Solutions for exercises 1-8 are in [solutions/](solutions/)

Quick launcher:
- Run [start_exercises.py](start_exercises.py) to select and run starter/solution scripts.
- Run [generate_exercise_docx.py](generate_exercise_docx.py) to regenerate exercise4-8 DOCX files.
