**Exercise 3 — Minimal CLI RAG over a Local Document**

- **Goal:** Build a Retrieval-Augmented Generation pipeline over `constitution.txt` using LangChain, Chroma, and Ollama.
- **Prerequisites:**
  - Ollama server: `ollama serve`
  - Models: `ollama pull llama3.2` and `ollama pull mxbai-embed-large`
  - Packages: `pip install ollama chromadb langchain-ollama langchain-community langchain-text-splitters`
- **Tasks:**
  - Load `constitution.txt` and split into chunks with `RecursiveCharacterTextSplitter` (chunk_size≈800, overlap≈100).
  - Create `OllamaEmbeddings(model='mxbai-embed-large')` and embed chunks.
  - Store vectors in an in-memory Chroma collection and implement top-k retrieval for a question.
  - Compose a final prompt with retrieved context and use Ollama SDK (`llama3.2`) to generate the answer.
  - Print the question, a few retrieved snippets, and the final answer.
- **Acceptance Criteria:**
  - Answer references the provided context and avoids hallucinations when information is missing.
  - Code handles common errors (e.g., server not running, model missing).
- **Reference Solution:** [solutions/ex3_solution.py](solutions/ex3_solution.py)
- **Run:**

```powershell
# Using the repo venv
D:\kurs\datascience\EgneKurs\ollama_langchain_rag\ollama_book_source_codes\.venv\Scripts\python.exe solutions\ex3_solution.py "What are the powers of Congress?"

# Or using system Python
python solutions/ex3_solution.py "What are the powers of Congress?"
```
