**Exercise 2 — LangChain Pipeline with Structured Output**

- **Goal:** Use LangChain's `ChatOllama` and `ChatPromptTemplate` to classify a short product review and return valid JSON.
- **Prerequisites:**
  - Ollama server and model: `ollama serve`, `ollama pull llama3.2`
  - Packages: `pip install langchain-core langchain-community langchain-ollama`
- **Tasks:**
  - Create a `ChatPromptTemplate` with a system role describing the JSON schema and a human message containing the review.
  - Instantiate `ChatOllama(model='llama3.2', temperature=0.2)`.
  - Compose `prompt → llm → StrOutputParser` using the `|` operator.
  - Invoke the chain, parse JSON, and print pretty-formatted.
  - Handle non-JSON outputs gracefully (fallback to raw text).
- **Acceptance Criteria:**
  - Chain returns valid JSON with keys: `sentiment`, `aspects`, `summary`.
  - Readable console output and robust handling of parsing errors.
- **Reference Solution:** [solutions/ex2_solution.py](solutions/ex2_solution.py)
- **Run:**

```powershell
# Using the repo venv
D:\kurs\datascience\EgneKurs\ollama_langchain_rag\ollama_book_source_codes\.venv\Scripts\python.exe solutions\ex2_solution.py

# Or using system Python
python solutions/ex2_solution.py
```
